// 지수 관측소 v5.5 — 나스닥 한국장 선행 잔차 + 전용 정규화 + VIX3M·DAX 확장 + 1일/5일 듀얼 호라이즌

var MIN_BASE_SAMPLES = 18;
var MIN_EXTRA_SAMPLES = 60;
var MIN_CONVICTION_SAMPLES = 20;
var RECENCY_HALF_LIFE = 380; // 최근 1.5년 장세에 더 높은 가중치 부여 (코스피/5일)

var FEATURE_META = {
  KR: [
    { key: 'ret1', label: '당일 등락률', unit: '%', min: -8, max: 8, step: 0.1 },
    { key: 'retPrev', label: '전일 등락률', unit: '%', min: -8, max: 8, step: 0.1 },
    { key: 'ret5', label: '5거래일 모멘텀', unit: '%', min: -15, max: 15, step: 0.2 },
    { key: 'vol10', label: '10일 실현변동성', unit: '%', min: 0.3, max: 6, step: 0.1 },
    { key: 'fx1', label: '원/달러 환율 변화', unit: '%', min: -3, max: 3, step: 0.05 },
    { key: 'usRet', label: '직전 나스닥 누적 등락', unit: '%', min: -10, max: 10, step: 0.1 }
  ],
  US: [
    { key: 'ret1', label: '당일 등락률', unit: '%', min: -8, max: 8, step: 0.1 },
    { key: 'retPrev', label: '전일 등락률', unit: '%', min: -8, max: 8, step: 0.1 },
    { key: 'ret5', label: '5거래일 모멘텀', unit: '%', min: -15, max: 15, step: 0.2 },
    { key: 'vol10', label: '10일 실현변동성', unit: '%', min: 0.3, max: 6, step: 0.1 }
  ]
};

var EXTRA_META = {
  sox: { key: 'sox', label: 'SOX − 나스닥 상대강도', unit: '%p', min: -12, max: 12, step: 0.1 },
  breadth: { key: 'breadth', label: '코스닥 상승 종목 비율', unit: '%', min: 0, max: 100, step: 0.5 },
  flow: { key: 'flow', label: '외국인 현물 순매수 강도', unit: '%', min: -25, max: 25, step: 0.1 },
  vix: { key: 'vix', label: 'VIX 변동성 지수', unit: 'pt', min: 10, max: 60, step: 0.5 },
  vixRatio: { key: 'vixRatio', label: 'VIX / VIX3M 기간구조', unit: 'x', min: 0.6, max: 1.5, step: 0.02 },
  tnx: { key: 'tnx', label: '미 국채 10년물 일간 변화', unit: '%p', min: -0.4, max: 0.4, step: 0.01 },
  dxy: { key: 'dxy', label: '달러 인덱스(DXY) 변화', unit: '%', min: -3, max: 3, step: 0.05 },
  oil: { key: 'oil', label: 'WTI 국제유가 변화', unit: '%', min: -10, max: 10, step: 0.2 },
  gold: { key: 'gold', label: '국제 금 선물 변화', unit: '%', min: -6, max: 6, step: 0.1 },
  usVix: { key: 'usVix', label: '나스닥×VIX 충격 상호작용', unit: '', min: -15, max: 15, step: 0.2 },
  ret20: { key: 'ret20', label: '20거래일 중기 추세', unit: '%', min: -25, max: 25, step: 0.5 },
  krLead: { key: 'krLead', label: '한국장(코스피) 장전 등락', unit: '%', min: -8, max: 8, step: 0.1 },
  krResid: { key: 'krResid', label: '코스피 장전 독자 변동분', unit: '%p', min: -6, max: 6, step: 0.1 },
  dax: { key: 'dax', label: '유럽장(독일 DAX) 등락', unit: '%', min: -8, max: 8, step: 0.1 },
  news: { key: 'news', label: '글로벌 뉴스 심리', unit: '점', min: -100, max: 100, step: 5 },
  krFut: { key: 'krFut', label: '코스피200 선물 등락', unit: '%', min: -6, max: 6, step: 0.1 },
  krBasis: { key: 'krBasis', label: '코스피200 선물 베이시스', unit: 'pt', min: -5, max: 5, step: 0.1 }
};

function getConvictionThreshold(marketKey) {
  return marketKey === 'NASDAQ' ? 0.60 : 0.65;
}

function quantile(values, p) {
  if (!values || !values.length) return null;
  var sorted = values.slice().sort((a, b) => a - b);
  var idx = Math.max(0, Math.min(sorted.length - 1, (sorted.length - 1) * p));
  var lo = Math.floor(idx);
  var hi = Math.ceil(idx);
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}

function adjacent(a, b) {
  return Boolean(
    a &&
    b &&
    (Date.parse(b[0]) - Date.parse(a[0])) / 86400000 <= 7 &&
    Math.abs((b[1] / a[1] - 1) * 100 - b[2]) < 0.012
  );
}

function sigmoid(z) {
  if (z > 20) return 1;
  if (z < -20) return 0;
  return 1 / (1 + Math.exp(-z));
}

function findLastIndexOnOrBefore(rows, dateStr) {
  if (!rows || !rows.length) return -1;
  var lo = 0;
  var hi = rows.length - 1;
  var ans = -1;
  while (lo <= hi) {
    var mid = (lo + hi) >> 1;
    if (rows[mid][0] <= dateStr) {
      ans = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  return ans;
}

function cumulativeUsReturn(nasdaqRows, prevKrDate, curKrDate) {
  var curIdx = findLastIndexOnOrBefore(nasdaqRows, curKrDate);
  if (curIdx < 0) return { ret: 0, usDate: null, sessions: 0 };
  var prevIdx = prevKrDate ? findLastIndexOnOrBefore(nasdaqRows, prevKrDate) : curIdx - 1;
  if (prevIdx >= 0 && curIdx > prevIdx && curIdx - prevIdx <= 5) {
    var cumRet = (nasdaqRows[curIdx][1] / nasdaqRows[prevIdx][1] - 1) * 100;
    return { ret: cumRet, usDate: nasdaqRows[curIdx][0], sessions: curIdx - prevIdx };
  }
  return { ret: nasdaqRows[curIdx][2], usDate: nasdaqRows[curIdx][0], sessions: 1 };
}

function buildDiffMap(series, isPct) {
  var map = new Map();
  if (!series || series.length < 2) return map;
  for (var i = 1; i < series.length; i++) {
    var [date, val] = series[i];
    var prev = series[i - 1][1];
    if (Number.isFinite(val) && Number.isFinite(prev) && prev !== 0) {
      map.set(date, isPct ? (val / prev - 1) * 100 : val - prev);
    }
  }
  return map;
}

function findPreUsKoreaSession(nasdaqDate, nextNasdaqDate, maps) {
  if (nextNasdaqDate) {
    var ret = maps.kospiByDate.get(nextNasdaqDate);
    if (Number.isFinite(ret)) return { ret, krDate: nextNasdaqDate };
    return { ret: undefined, krDate: null };
  }
  // 최신일 실시간 예측: 미국 전일 종가(nasdaqDate) 이후 먼저 마감한 한국장 세션 탐색 (최대 5일 이내)
  var dates = maps.kospiDates;
  for (var i = dates.length - 1; i >= 0; i--) {
    var d = dates[i];
    if (d <= nasdaqDate) break;
    var gap = (Date.parse(d) - Date.parse(nasdaqDate)) / 86400000;
    if (gap > 0 && gap <= 5) {
      return { ret: maps.kospiByDate.get(d), krDate: d };
    }
  }
  return { ret: undefined, krDate: null };
}

function extractBaseFeatures(rows, i, marketKey, allMarkets) {
  if (i < 5) return null;
  var today = rows[i];
  var prev = rows[i - 1];
  if (!prev || !adjacent(prev, today)) return null;

  var ret5 = rows[i - 5][1] ? (today[1] / rows[i - 5][1] - 1) * 100 : 0;
  var ret20 = i >= 20 && rows[i - 20][1] ? (today[1] / rows[i - 20][1] - 1) * 100 : undefined;
  var winStart = Math.max(0, i - 9);
  var rets = [];
  for (var k = winStart; k <= i; k++) rets.push(rows[k][2]);
  var meanR = rets.reduce((a, b) => a + b, 0) / rets.length;
  var variance = rets.reduce((a, b) => a + (b - meanR) ** 2, 0) / Math.max(1, rets.length - 1);
  var vol10 = Math.sqrt(variance) || 1.0;

  var feats = [today[2], prev[2], ret5, vol10];
  var usInfo = { ret: 0, usDate: null, sessions: 0 };
  if (marketKey !== 'NASDAQ') {
    var fxChg = today[3] && prev[3] ? (today[3] / prev[3] - 1) * 100 : 0;
    usInfo = cumulativeUsReturn(allMarkets.NASDAQ || [], prev[0], today[0]);
    feats.push(fxChg, usInfo.ret);
  }
  return {
    feats,
    vol: vol10,
    ret1: today[2],
    ret20,
    usRet: usInfo.ret,
    usDate: usInfo.usDate,
    usSessions: usInfo.sessions
  };
}

function fitLogisticModel(pool, d, warm, useRecency, l2Floor) {
  var n = pool.length;
  var sw = new Array(n);
  var wSum = 0;
  var decay = useRecency ? Math.LN2 / RECENCY_HALF_LIFE : 0;
  for (var i = 0; i < n; i++) {
    var wt = useRecency ? Math.exp(-decay * (n - 1 - i)) : 1;
    sw[i] = wt;
    wSum += wt;
  }
  var normFactor = n / wSum;
  var upSum = 0;
  for (var i = 0; i < n; i++) {
    sw[i] *= normFactor;
    upSum += sw[i] * pool[i].up;
  }
  var baseRate = upSum / n;

  var means = new Array(d);
  var stds = new Array(d);
  for (var j = 0; j < d; j++) {
    var s = 0;
    for (var i = 0; i < n; i++) s += sw[i] * pool[i].x[j];
    var mean = s / n;
    var v = 0;
    for (var i = 0; i < n; i++) {
      var diff = pool[i].x[j] - mean;
      v += sw[i] * diff * diff;
    }
    means[j] = mean;
    stds[j] = Math.sqrt(v / n) || 1;
  }

  var X = new Array(n);
  for (var i = 0; i < n; i++) {
    var row = new Array(d);
    var rx = pool[i].x;
    for (var j = 0; j < d; j++) {
      var z = (rx[j] - means[j]) / stds[j];
      row[j] = z > 3 ? 3 : z < -3 ? -3 : z;
    }
    X[i] = row;
  }

  var baseLambda = Math.max(l2Floor || 10, (280 / Math.sqrt(n)) * Math.sqrt(d / 6));
  var clampedBase = Math.max(0.05, Math.min(0.95, baseRate));
  var useWarm = warm && warm.w && warm.w.length === d;
  var b = useWarm ? warm.b : Math.log(clampedBase / (1 - clampedBase));
  var w = useWarm ? warm.w.slice() : new Array(d).fill(0);
  var lr = 0.08;
  var iters = useWarm ? 14 : 110;

  for (var iter = 0; iter < iters; iter++) {
    var gb = 0;
    var gw = new Array(d).fill(0);
    for (var i = 0; i < n; i++) {
      var z = b;
      for (var j = 0; j < d; j++) z += w[j] * X[i][j];
      var err = sw[i] * (sigmoid(z) - pool[i].up);
      gb += err;
      for (var j = 0; j < d; j++) gw[j] += err * X[i][j];
    }
    b -= lr * (gb / n);
    for (var j = 0; j < d; j++) {
      w[j] -= lr * (gw[j] / n + (baseLambda / n) * w[j]);
    }
  }

  var stdRets = pool.map(r => r.y / Math.max(0.35, r.vol));
  var qLo = quantile(stdRets, Math.max(0.02, 0.1 - 0.5 / (n + 1)));
  var qHi = quantile(stdRets, Math.min(0.98, 0.9 + 0.5 / (n + 1)));
  var ups = pool.filter(r => r.y > 0).map(r => r.y);
  var downs = pool.filter(r => r.y < 0).map(r => r.y);
  var volMedian = quantile(pool.map(r => r.vol), 0.5) || 1.2;

  return {
    n,
    baseRate,
    means,
    stds,
    b,
    w,
    qLo,
    qHi,
    volMedian,
    gain: quantile(ups, 0.5),
    loss: quantile(downs, 0.5)
  };
}

function classifySignal(p, marketKey) {
  var thr = getConvictionThreshold(marketKey);
  if (p >= thr) return { code: 'HIGH_UP', label: '고확신 상승 신호', tone: 'teal' };
  if (p <= 1 - thr) return { code: 'HIGH_DOWN', label: '고확신 하락 경계', tone: 'rose' };
  return { code: 'NEUTRAL', label: '중립 · 관망 구간', tone: 'slate' };
}

function predictWithModel(model, rawFeats, vol, marketKey, selectedMeta, horizon) {
  var xNow = rawFeats.map((v, j) =>
    Math.max(-3, Math.min(3, (v - model.means[j]) / model.stds[j]))
  );
  var zNow = model.b;
  var rawTerms = [];
  for (var j = 0; j < xNow.length; j++) {
    var term = model.w[j] * xNow[j];
    rawTerms.push(term);
    zNow += term;
  }
  var rawP = sigmoid(zNow);
  var trust = model.n / (model.n + 60);
  var p = trust * rawP + (1 - trust) * model.baseRate;
  var down = Math.max(0, 1 - p);

  var slope = rawP * (1 - rawP) * trust * 100;
  var meta = selectedMeta || (marketKey === 'NASDAQ' ? FEATURE_META.US : FEATURE_META.KR);
  var contributions = meta.map((m, j) => ({
    key: m.key,
    label: m.label,
    unit: m.unit,
    value: rawFeats[j],
    impactPct: rawTerms[j] * slope
  }));

  var curVol = Math.max(0.35, vol);
  var low = model.qLo * curVol;
  var high = model.qHi * curVol;
  var score = Math.round(p * 100);

  var volRatio = curVol / Math.max(0.35, model.volMedian || 1.2);
  var regime = '보통 변동성';
  var regimeTone = 'slate';
  if (volRatio >= 1.35) {
    regime = '고변동 경계';
    regimeTone = 'rose';
  } else if (volRatio <= 0.75) {
    regime = '저변동 안정';
    regimeTone = 'teal';
  }

  return {
    horizon: horizon || 1,
    n: model.n,
    p,
    down,
    base: model.baseRate,
    score,
    signal: classifySignal(p, marketKey),
    low,
    high,
    gain: model.gain,
    loss: model.loss,
    vol: curVol,
    volRatio,
    regime,
    regimeTone,
    rawFeats: rawFeats.slice(),
    contributions,
    meta,
    modelRef: model
  };
}

function buildMacroMaps(data) {
  var us = data.NASDAQ || [];
  var soxMap = new Map(data.SOX || []);
  var soxSpreads = new Map();
  for (var i = 1; i < us.length; i++) {
    var [date, , ret] = us[i];
    var prev = soxMap.get(us[i - 1][0]);
    var close = soxMap.get(date);
    if (prev > 0 && close > 0) soxSpreads.set(date, (close / prev - 1) * 100 - ret);
  }
  var kospiRows = data.KOSPI || [];
  var kospiByDate = new Map();
  var kospiDates = [];
  for (var i = 0; i < kospiRows.length; i++) {
    kospiByDate.set(kospiRows[i][0], kospiRows[i][2]);
    kospiDates.push(kospiRows[i][0]);
  }
  return {
    soxSpreads,
    vixMap: new Map(data.VIX || []),
    vix3mMap: new Map(data.VIX3M || []),
    tnxDiff: buildDiffMap(data.TNX || [], false),
    dxyPct: buildDiffMap(data.DXY || [], true),
    oilPct: buildDiffMap(data.CL || [], true),
    goldPct: buildDiffMap(data.GC || [], true),
    daxPct: buildDiffMap(data.DAX || [], true),
    newsMap: new Map(data.NEWS_HIST || []),
    krFutMap: new Map((data.KR_FUT_HIST || []).map(r => [r[0], r[1]])),
    krBasisMap: new Map((data.KR_FUT_HIST || []).map(r => [r[0], r[2]])),
    kospiByDate,
    kospiDates
  };
}

function getCandidateKeys(key, horizon) {
  if (key === 'NASDAQ') {
    return horizon === 5
      ? ['vix', 'vixRatio', 'tnx', 'dxy', 'ret20', 'oil', 'gold']
      : ['krLead', 'krResid', 'vixRatio', 'dax', 'vix', 'tnx', 'dxy', 'news'];
  }
  if (key === 'KOSPI') {
    return horizon === 5
      ? ['sox', 'vix', 'ret20', 'oil', 'gold']
      : ['sox', 'vix', 'usVix', 'flow', 'oil', 'gold', 'krFut', 'krBasis', 'news'];
  }
  return horizon === 5
    ? ['vix', 'ret20', 'oil', 'gold']
    : ['breadth', 'flow', 'vix', 'oil', 'gold', 'krFut', 'news'];
}

function makeExtraRecord(refUsDate, breadth, flow, maps, current, key, nextUsDate, curDate) {
  var vixVal = refUsDate ? maps.vixMap.get(refUsDate) : undefined;
  var vix3mVal = refUsDate ? maps.vix3mMap.get(refUsDate) : undefined;
  var vixRatio =
    Number.isFinite(vixVal) && Number.isFinite(vix3mVal) && vix3mVal > 0
      ? vixVal / vix3mVal
      : undefined;
  var usVix =
    Number.isFinite(vixVal) && current && Number.isFinite(current.usRet)
      ? current.usRet * (vixVal / 20)
      : undefined;

  var krLead;
  var krResid;
  var krLeadDate = null;
  if (key === 'NASDAQ' && refUsDate) {
    var kr = findPreUsKoreaSession(refUsDate, nextUsDate, maps);
    if (Number.isFinite(kr.ret)) {
      krLead = kr.ret;
      krResid = current && Number.isFinite(current.ret1) ? kr.ret - 0.55 * current.ret1 : kr.ret;
      krLeadDate = kr.krDate;
    }
  }

  return {
    sox: refUsDate ? maps.soxSpreads.get(refUsDate) : undefined,
    breadth: Number.isFinite(breadth) ? breadth : undefined,
    flow: Number.isFinite(flow) ? flow : undefined,
    vix: vixVal,
    vixRatio,
    tnx: refUsDate ? maps.tnxDiff.get(refUsDate) : undefined,
    dxy: refUsDate ? maps.dxyPct.get(refUsDate) : undefined,
    oil: refUsDate ? maps.oilPct.get(refUsDate) : undefined,
    gold: refUsDate ? maps.goldPct.get(refUsDate) : undefined,
    dax: refUsDate ? maps.daxPct.get(refUsDate) : undefined,
    news: (curDate && maps.newsMap.get(curDate) !== undefined) ? maps.newsMap.get(curDate) : (refUsDate ? maps.newsMap.get(refUsDate) : undefined),
    krFut: (curDate && maps.krFutMap.get(curDate) !== undefined) ? maps.krFutMap.get(curDate) : (refUsDate ? maps.krFutMap.get(refUsDate) : undefined),
    krBasis: (curDate && maps.krBasisMap.get(curDate) !== undefined) ? maps.krBasisMap.get(curDate) : (refUsDate ? maps.krBasisMap.get(refUsDate) : undefined),
    usVix,
    ret20: current ? current.ret20 : undefined,
    krLead,
    krResid,
    _krLeadDate: krLeadDate
  };
}

function selectActiveExtras(candidates, extra, pool) {
  var minRequired = Math.max(MIN_EXTRA_SAMPLES, Math.ceil(pool.length * 0.72));
  var available = candidates.filter(k => Number.isFinite(extra[k]));
  var qualifying = available.filter(k => {
    var cnt = 0;
    for (var i = 0; i < pool.length; i++) if (Number.isFinite(pool[i].extra[k])) cnt++;
    return cnt >= minRequired;
  });
  if (qualifying.length) {
    var jointEligible = pool.filter(row => qualifying.every(k => Number.isFinite(row.extra[k])));
    if (jointEligible.length >= minRequired) {
      return { keys: qualifying, eligible: jointEligible };
    }
    var first = [qualifying[0]];
    var singleEligible = pool.filter(row => Number.isFinite(row.extra[first[0]]));
    return { keys: first, eligible: singleEligible };
  }
  return { keys: [], eligible: pool };
}

function forwardReturn(rows, i, horizon) {
  if (i + horizon >= rows.length) return null;
  if (horizon === 1) return adjacent(rows[i], rows[i + 1]) ? rows[i + 1][2] : null;
  var days = (Date.parse(rows[i + horizon][0]) - Date.parse(rows[i][0])) / 86400000;
  if (days > 14 || !rows[i][1]) return null;
  return (rows[i + horizon][1] / rows[i][1] - 1) * 100;
}

function getModelHyperparams(key, horizon) {
  if (key === 'NASDAQ' && horizon === 1) {
    return { useRecency: false, l2Floor: 55 };
  }
  return { useRecency: horizon === 5 || key === 'KOSPI', l2Floor: 10 };
}

function buildHistories(rows, key, data, horizon) {
  var h = horizon || 1;
  var baseMeta = key === 'NASDAQ' ? FEATURE_META.US : FEATURE_META.KR;
  var candidates = getCandidateKeys(key, h);
  var maps = buildMacroMaps(data);
  var hp = getModelHyperparams(key, h);

  var base = [];
  var enhanced = [];
  var pool = [];
  var prevBaseModel = null;
  var prevExtModel = null;
  var prevExtSig = '';

  var pending = [];

  for (var i = 0; i < rows.length; i++) {
    while (pending.length && pending[0].readyIdx <= i) {
      pool.push(pending.shift().item);
    }

    var [date, , , , breadth, flow] = rows[i];
    var nextUsDate = i + 1 < rows.length ? rows[i + 1][0] : null;
    var current = extractBaseFeatures(rows, i, key, data);
    var refUsDate = key === 'NASDAQ' ? date : current ? current.usDate : null;
    var extra = makeExtraRecord(refUsDate, breadth, flow, maps, current, key, nextUsDate, date);

    var f = null;
    var g = null;
    if (current && pool.length >= MIN_BASE_SAMPLES) {
      var baseModel = fitLogisticModel(pool, baseMeta.length, prevBaseModel, false, 10);
      prevBaseModel = baseModel;
      f = predictWithModel(baseModel, current.feats, current.vol, key, baseMeta, h);
      g = f;

      var sel = selectActiveExtras(candidates, extra, pool);
      if (sel.keys.length) {
        var isNasdaqLeadOnly = key === 'NASDAQ' && h === 1 && sel.keys.includes('krLead');
        var useFeats = isNasdaqLeadOnly ? [] : current.feats;
        var useMeta = isNasdaqLeadOnly ? [] : baseMeta;
        var training = sel.eligible.map(row => (Object.assign({}, row, {
          x: (isNasdaqLeadOnly ? [] : row.x).concat(sel.keys.map(k => row.extra[k]))
        })));
        var meta = useMeta.concat(sel.keys.map(k => EXTRA_META[k]));
        var sig = (isNasdaqLeadOnly ? 'lead:' : 'full:') + sel.keys.join('+');
        var extModel = fitLogisticModel(
          training,
          meta.length,
          sig === prevExtSig ? prevExtModel : null,
          hp.useRecency,
          hp.l2Floor
        );
        prevExtModel = extModel;
        prevExtSig = sig;
        g = predictWithModel(
          extModel,
          useFeats.concat(sel.keys.map(k => extra[k])),
          current.vol,
          key,
          meta,
          h
        );
      } else if (hp.useRecency || hp.l2Floor > 10) {
        var recModel = fitLogisticModel(pool, baseMeta.length, null, hp.useRecency, hp.l2Floor);
        g = predictWithModel(recModel, current.feats, current.vol, key, baseMeta, h);
      }

      g = Object.assign({}, g, {
        usDate: refUsDate,
        usSessions: current.usSessions,
        krLeadDate: extra._krLeadDate,
        extra,
        active: sel.keys,
        candidates
      });
    }

    base.push(f);
    enhanced.push(g);

    var y = forwardReturn(rows, i, h);
    if (current && y !== null) {
      pending.push({
        readyIdx: i + h,
        item: { x: current.feats, vol: current.vol, y, up: Number(y > 0), extra }
      });
    }
  }
  return { base, enhanced };
}

function forecastSingleDay(rows, targetIdx, key, data, horizon) {
  var h = horizon || 1;
  var baseMeta = key === 'NASDAQ' ? FEATURE_META.US : FEATURE_META.KR;
  var candidates = getCandidateKeys(key, h);
  var maps = buildMacroMaps(data);
  var hp = getModelHyperparams(key, h);

  var current = extractBaseFeatures(rows, targetIdx, key, data);
  if (!current) return null;

  var pool = [];
  for (var i = 5; i <= targetIdx - h; i++) {
    var f = extractBaseFeatures(rows, i, key, data);
    var y = forwardReturn(rows, i, h);
    if (!f || y === null) continue;
    var [date, , , , breadth, flow] = rows[i];
    var nextUsDate = i + 1 < rows.length ? rows[i + 1][0] : null;
    var refUs = key === 'NASDAQ' ? date : f.usDate;
    pool.push({
      x: f.feats,
      vol: f.vol,
      y,
      up: Number(y > 0),
      extra: makeExtraRecord(refUs, breadth, flow, maps, f, key, nextUsDate, date)
    });
  }
  if (pool.length < MIN_BASE_SAMPLES) return null;

  var [curDate, , , , curBreadth, curFlow] = rows[targetIdx];
  var nextUsDate = targetIdx + 1 < rows.length ? rows[targetIdx + 1][0] : null;
  var refUsDate = key === 'NASDAQ' ? curDate : current.usDate;
  var extra = makeExtraRecord(refUsDate, curBreadth, curFlow, maps, current, key, nextUsDate, curDate);

  var baseModel = fitLogisticModel(pool, baseMeta.length, null, hp.useRecency, hp.l2Floor);
  var g = predictWithModel(baseModel, current.feats, current.vol, key, baseMeta, h);

  var sel = selectActiveExtras(candidates, extra, pool);
  if (sel.keys.length) {
    var isNasdaqLeadOnly = key === 'NASDAQ' && h === 1 && sel.keys.includes('krLead');
    var useFeats = isNasdaqLeadOnly ? [] : current.feats;
    var useMeta = isNasdaqLeadOnly ? [] : baseMeta;
    var training = sel.eligible.map(row => (Object.assign({}, row, {
      x: (isNasdaqLeadOnly ? [] : row.x).concat(sel.keys.map(k => row.extra[k]))
    })));
    var meta = useMeta.concat(sel.keys.map(k => EXTRA_META[k]));
    var extModel = fitLogisticModel(training, meta.length, null, hp.useRecency, hp.l2Floor);
    g = predictWithModel(
      extModel,
      useFeats.concat(sel.keys.map(k => extra[k])),
      current.vol,
      key,
      meta,
      h
    );
  }

  return Object.assign({}, g, {
    usDate: refUsDate,
    usSessions: current.usSessions,
    krLeadDate: extra._krLeadDate,
    extra,
    active: sel.keys,
    candidates
  });
}

function featuresV1(rows, i) {
  var today = rows[i];
  var prev = rows[i - 1];
  if (!prev || !adjacent(prev, today)) return null;
  var signals = [today[2], prev[2]];
  if (today[3] && prev[3]) signals.push(100 * (today[3] / prev[3] - 1));
  return signals;
}

function forecastV1(rows, end) {
  var now = featuresV1(rows, end);
  if (!now) return null;
  var pool = [];
  for (var i = 1; i < end; i++) {
    var x = featuresV1(rows, i);
    if (x && adjacent(rows[i], rows[i + 1])) pool.push({ x, y: rows[i + 1][2] });
  }
  if (pool.length < MIN_BASE_SAMPLES) return null;
  var scales = now.map((_, j) => {
    var col = pool.map(row => row.x[j]);
    return Math.max(0.05, quantile(col, 0.75) - quantile(col, 0.25));
  });
  for (var row of pool) {
    row.distance = now.reduce((s, v, j) => s + ((v - row.x[j]) / scales[j]) ** 2, 0);
  }
  var k = Math.min(pool.length, Math.max(12, Math.round(2 * Math.sqrt(pool.length))));
  var outcomes = pool.sort((a, b) => a.distance - b.distance).slice(0, k).map(r => r.y);
  var up = outcomes.filter(x => x > 0);
  var down = outcomes.filter(x => x < 0);
  return {
    k,
    p: up.length / k,
    down: down.length / k,
    base: pool.filter(r => r.y > 0).length / pool.length,
    low: quantile(outcomes, 0.1),
    high: quantile(outcomes, 0.9),
    gain: quantile(up, 0.5),
    loss: quantile(down, 0.5)
  };
}

// 실시간 글로벌 뉴스 투심 보정 (과거 60일 이력 축적 전 최신일 전망용, 최대 약 ±4.5%p)
function applyNewsOverlay(forecast, sentimentScore, marketKey, enabled) {
  if (!forecast) return forecast;
  var score = Number.isFinite(sentimentScore) ? Math.max(-100, Math.min(100, sentimentScore)) : 0;
  // 이미 학습 모델에 news가 정식 반영된 경우 중복 보정 방지
  var alreadyLearned = Array.isArray(forecast.active) && forecast.active.includes('news');
  if (!enabled || alreadyLearned || score === 0) {
    return Object.assign({}, forecast, {
      pureP: forecast.p,
      newsImpactPct: 0,
      newsApplied: false,
      newsScore: score
    });
  }
  var pClamped = Math.max(0.02, Math.min(0.98, forecast.p));
  var baseLogit = Math.log(pClamped / (1 - pClamped));
  var deltaLogit = (score / 100) * 0.18; // ~±4.5%p at p=0.50, scaled smoothly near extremes
  var adjP = sigmoid(baseLogit + deltaLogit);
  var impactPct = (adjP - forecast.p) * 100;
  return Object.assign({}, forecast, {
    pureP: forecast.p,
    p: adjP,
    down: Math.max(0, 1 - adjP),
    score: Math.round(adjP * 100),
    signal: classifySignal(adjP, marketKey),
    newsImpactPct: impactPct,
    newsApplied: true,
    newsScore: score,
    contributions: forecast.contributions.concat([
      {
        key: 'newsOverlay',
        label: '글로벌 뉴스 투심 보정',
        unit: '점',
        value: score,
        impactPct
      }
    ])
  });
}

// 실시간 코스피200 국내선물 보정 (60일 누적 학습 전 최신일 코스피·코스닥 전망용, 최대 약 ±7%p)
function applyKrFuturesOverlay(forecast, krFutPct, krBasis, marketKey, enabled) {
  if (!forecast) return forecast;
  if (marketKey === 'NASDAQ') {
    return Object.assign({}, forecast, { krFutApplied: false, krFutImpactPct: 0, krFutPct: 0 });
  }
  var pct = Number.isFinite(krFutPct) ? Math.max(-6, Math.min(6, krFutPct)) : 0;
  var basis = Number.isFinite(krBasis) ? Math.max(-5, Math.min(5, krBasis)) : 0;
  var alreadyLearned = Array.isArray(forecast.active) && forecast.active.includes('krFut');
  if (!enabled || alreadyLearned || (pct === 0 && basis === 0)) {
    return Object.assign({}, forecast, { krFutApplied: false, krFutImpactPct: 0, krFutPct: pct, krBasis: basis });
  }
  var pClamped = Math.max(0.02, Math.min(0.98, forecast.p));
  var baseLogit = Math.log(pClamped / (1 - pClamped));
  var deltaLogit = Math.max(-0.28, Math.min(0.28, pct * 0.10 + basis * 0.02));
  var adjP = sigmoid(baseLogit + deltaLogit);
  var impactPct = (adjP - forecast.p) * 100;
  return Object.assign({}, forecast, {
    p: adjP,
    down: Math.max(0, 1 - adjP),
    score: Math.round(adjP * 100),
    signal: classifySignal(adjP, marketKey),
    krFutApplied: true,
    krFutImpactPct: impactPct,
    krFutPct: pct,
    krBasis: basis,
    contributions: forecast.contributions.concat([
      {
        key: 'krFutOverlay',
        label: '코스피200 선물 보정',
        unit: '%',
        value: pct,
        impactPct
      }
    ])
  });
}

// ============================================================
// v7.0 개별 종목 업종별 선행지표 기반 실시간 예측 + 워크포워드 검증 엔진
// ============================================================
function fitStockLogistic(X, y, weights, lambda) {
  var n = X.length;
  var d = X[0].length;
  var mean = new Array(d).fill(0);
  var std = new Array(d).fill(1);
  var wSum = 0;
  for (var i = 0; i < n; i++) wSum += weights[i];
  for (var j = 0; j < d; j++) {
    var m = 0;
    for (var i = 0; i < n; i++) m += weights[i] * X[i][j];
    mean[j] = m / (wSum || 1);
    var v = 0;
    for (var i = 0; i < n; i++) v += weights[i] * (X[i][j] - mean[j]) ** 2;
    std[j] = Math.sqrt(v / (wSum || 1)) || 1;
  }

  var b = 0;
  var w = new Array(d).fill(0);
  var lr = 0.12;
  for (var iter = 0; iter < 90; iter++) {
    var gb = 0;
    var gw = new Array(d).fill(0);
    for (var i = 0; i < n; i++) {
      var z = b;
      for (var j = 0; j < d; j++) z += w[j] * ((X[i][j] - mean[j]) / std[j]);
      var p = 1 / (1 + Math.exp(-Math.max(-20, Math.min(20, z))));
      var err = (p - y[i]) * weights[i];
      gb += err;
      for (var j = 0; j < d; j++) gw[j] += err * ((X[i][j] - mean[j]) / std[j]);
    }
    b -= (lr * gb) / (wSum || 1);
    for (var j = 0; j < d; j++) {
      w[j] -= (lr * (gw[j] + (lambda * w[j]) / n)) / (wSum || 1);
    }
  }
  return { b, w, mean, std };
}

function predictStockRow(model, feat) {
  var z = model.b;
  var contribZ = [];
  for (var j = 0; j < feat.length; j++) {
    var cz = model.w[j] * ((feat[j] - model.mean[j]) / model.std[j]);
    z += cz;
    contribZ.push(cz);
  }
  var p = 1 / (1 + Math.exp(-Math.max(-20, Math.min(20, z))));
  var baseP = 1 / (1 + Math.exp(-Math.max(-20, Math.min(20, model.b))));
  var sumZ = contribZ.reduce((s, v) => s + v, 0);
  var scale = Math.abs(sumZ) > 1e-6 ? ((p - baseP) * 100) / sumZ : 0;
  return { p, contribPct: contribZ.map(cz => cz * scale) };
}

function lookupPeerVal(peerRows, targetDate, strictBefore, isLevel) {
  if (!Array.isArray(peerRows) || !peerRows.length) return null;
  var lo = 0;
  var hi = peerRows.length - 1;
  var ans = -1;
  while (lo <= hi) {
    var mid = (lo + hi) >> 1;
    var d = peerRows[mid][0];
    if (strictBefore ? d < targetDate : d <= targetDate) {
      ans = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  if (ans < 0) return null;
  return isLevel ? peerRows[ans][1] : peerRows[ans][2];
}

function analyzeIndividualStock(payload) {
  var rows = (payload && Array.isArray(payload.rows)) ? payload.rows : [];
  if (rows.length < 60) {
    return { error: '분석에 필요한 일봉 데이터가 부족합니다 (최소 60거래일 필요).' };
  }
  var isKr = Boolean(payload.isKr);
  var peers = Array.isArray(payload.peers) ? payload.peers : [];

  var meta = [
    { key: 'ret1', label: '종목 당일 등락률', unit: '%' },
    { key: 'ret5', label: '종목 5일 모멘텀', unit: '%' },
    { key: 'vol10', label: '10일 실현 변동성', unit: '%' }
  ];
  for (var pr of peers) {
    meta.push({
      key: pr.sym,
      label: pr.label,
      unit: pr.isLevel ? (pr.unit || '') : '%',
      isLevel: Boolean(pr.isLevel)
    });
  }

  var samples = [];
  for (var i = 10; i < rows.length; i++) {
    var curDate = rows[i][0];
    var ret1 = rows[i][2];
    var ret5 = rows[i - 5][1] > 0 ? ((rows[i][1] / rows[i - 5][1]) - 1) * 100 : 0;
    var wRets = [];
    for (var k = i - 9; k <= i; k++) wRets.push(rows[k][2]);
    var meanR = wRets.reduce((s, v) => s + v, 0) / wRets.length;
    var vol10 = Math.sqrt(wRets.reduce((s, v) => s + (v - meanR) ** 2, 0) / wRets.length) || 1;

    var feat = [ret1, ret5, vol10];
    var ok = true;
    for (var pr of peers) {
      // 뉴욕 거래일 기준 동일 날짜(d <= curDate) 미국장은 한국장(15:30 KST) 마감 후 ~ 다음날 한국장 개장 전에 마감되므로
      // 다음 거래일 한국 종목 예측의 핵심 야간 선행 신호임 (Zero Lookahead).
      var pv = lookupPeerVal(pr.rows, curDate, false, pr.isLevel);
      if (!Number.isFinite(pv)) {
        ok = false;
        break;
      }
      feat.push(pv);
    }
    if (!ok) continue;

    var nextRet = i + 1 < rows.length && rows[i][1] > 0 ? ((rows[i + 1][1] / rows[i][1]) - 1) * 100 : null;
    samples.push({ idx: i, date: curDate, close: rows[i][1], ret1, vol10, feat, nextRet });
  }

  if (samples.length < 55) {
    return { error: '선행지표와 날짜가 매칭되는 표본이 부족합니다.' };
  }

  var trainAll = samples.filter(s => s.nextRet !== null);
  var latest = samples[samples.length - 1];
  var halfLife = 420;
  var lambda = 95;
  var shrink = 0.72; // 개별 종목 노이즈 과신 방지용 확률 보정 계수

  // 1. 확장 윈도우 워크포워드 백테스트 (5년 표본, 15거래일마다 재학습)
  var warmup = Math.min(180, Math.floor(trainAll.length * 0.35));
  var curModel = null;
  var brierSum = 0;
  var baseBrierSum = 0;
  var covSum = 0;
  var evalN = 0;
  var hiN = 0;
  var hiHit = 0;
  var hiBrierSum = 0;

  for (var t = warmup; t < trainAll.length; t++) {
    if (!curModel || (t - warmup) % 15 === 0) {
      var slice = trainAll.slice(0, t);
      var X = slice.map(s => s.feat);
      var y = slice.map(s => (s.nextRet > 0 ? 1 : 0));
      var w = slice.map((_, k) => Math.pow(0.5, (slice.length - 1 - k) / halfLife));
      curModel = fitStockLogistic(X, y, w, lambda);
    }
    var s = trainAll[t];
    var rawPred = predictStockRow(curModel, s.feat);
    var pred = { p: 0.5 + shrink * (rawPred.p - 0.5), contribPct: rawPred.contribPct.map(v => v * shrink) };
    var actualUp = s.nextRet > 0 ? 1 : 0;
    var upRate = trainAll.slice(0, t).reduce((a, v) => a + (v.nextRet > 0 ? 1 : 0), 0) / t;
    brierSum += (pred.p - actualUp) ** 2;
    baseBrierSum += (upRate - actualUp) ** 2;
    var bandLo = -1.2816 * s.vol10;
    var bandHi = 1.2816 * s.vol10;
    if (s.nextRet >= bandLo && s.nextRet <= bandHi) covSum += 1;
    evalN += 1;
    if (pred.p >= 0.62 || pred.p <= 0.38) {
      hiN += 1;
      if ((pred.p >= 0.5) === (s.nextRet > 0)) hiHit += 1;
      hiBrierSum += (pred.p - actualUp) ** 2;
    }
  }

  // 2. 전체 최신 표본으로 최종 내일 예측 모델 학습
  var Xall = trainAll.map(s => s.feat);
  var yall = trainAll.map(s => (s.nextRet > 0 ? 1 : 0));
  var wall = trainAll.map((_, k) => Math.pow(0.5, (trainAll.length - 1 - k) / halfLife));
  var finalModel = fitStockLogistic(Xall, yall, wall, lambda);
  var rawOut = predictStockRow(finalModel, latest.feat);
  var out = { p: 0.5 + shrink * (rawOut.p - 0.5), contribPct: rawOut.contribPct.map(v => v * shrink) };

  var upRets = trainAll.filter(s => s.nextRet > 0).map(s => s.nextRet).sort((a, b) => a - b);
  var dnRets = trainAll.filter(s => s.nextRet <= 0).map(s => s.nextRet).sort((a, b) => a - b);
  var med = arr => (arr.length ? arr[Math.floor(arr.length / 2)] : 0);
  var gainMed = med(upRets);
  var lossMed = med(dnRets);
  var baseUp = yall.reduce((a, v) => a + v, 0) / (yall.length || 1);

  // 80% 시나리오 밴드 (변동성 기반 + 확률 중심 이동)
  var drift = (out.p - 0.5) * latest.vol10 * 0.6;
  var lowPct = Number((drift - 1.2816 * latest.vol10).toFixed(2));
  var highPct = Number((drift + 1.2816 * latest.vol10).toFixed(2));
  var loPrice = latest.close * (1 + lowPct / 100);
  var hiPrice = latest.close * (1 + highPct / 100);

  var brierModel = evalN ? brierSum / evalN : null;
  var brierBase = evalN ? baseBrierSum / evalN : null;
  var edge = brierModel !== null && brierBase !== null ? brierBase - brierModel : 0;

  var reliability = { label: '중립 (보조 참고)', tone: 'amber', desc: '과거 기준 빈도와 유사한 수준입니다. 종목 공시·수급을 함께 확인하세요.' };
  if (edge > 0.004) {
    reliability = { label: '선행지표 설명력 양호', tone: 'teal', desc: '과거 워크포워드 검증에서 단순 기준 모델보다 우수한 확률 오차를 기록했습니다.' };
  } else if (edge <= -0.003) {
    reliability = { label: '고유 변동성 큼 (공시·수급 주의)', tone: 'rose', desc: '거시·업종 지표보다 실적·공시·수급 영향이 큰 종목입니다. 참고용으로만 보세요.' };
  }

  var signal = { label: '중립 · 관망 구간', tone: 'slate' };
  if (out.p >= 0.62) signal = { label: '고확신 상승 우위', tone: 'teal' };
  else if (out.p <= 0.38) signal = { label: '고확신 하락 경계', tone: 'rose' };

  var contributions = meta
    .map((m, idx) => ({
      key: m.key,
      label: m.label,
      value: latest.feat[idx],
      unit: m.unit,
      isLevel: Boolean(m.isLevel),
      impactPct: out.contribPct[idx] || 0
    }))
    .sort((a, b) => Math.abs(b.impactPct) - Math.abs(a.impactPct));

  return {
    symbol: payload.symbol,
    name: payload.name,
    sector: payload.sector,
    sectorLabel: payload.sectorLabel,
    currency: payload.currency || (isKr ? 'KRW' : 'USD'),
    isKr,
    isLiveIntraday: Boolean(payload.isLiveIntraday),
    updatedKst: payload.updatedKst || '',
    date: latest.date,
    close: latest.close,
    ret1: latest.ret1,
    vol10: latest.vol10,
    p: out.p,
    down: 1 - out.p,
    score: Math.round(out.p * 100),
    base: baseUp,
    lowPct,
    highPct,
    loPrice,
    hiPrice,
    gainMed,
    lossMed,
    signal,
    reliability,
    contributions,
    recentRows: rows.slice(-30),
    perp: payload.perp || null,
    news: Array.isArray(payload.news) ? payload.news : [],
    backtest: {
      n: evalN,
      trainN: trainAll.length,
      brierModel,
      brierBase,
      cov80: evalN ? covSum / evalN : null,
      hiN,
      hiAcc: hiN >= 15 ? hiHit / hiN : null,
      hiBrier: hiN >= 15 ? hiBrierSum / hiN : null
    }
  };
}

function applyStockPerpOverlay(analysis, usePerp) {
  if (!analysis || analysis.error) return analysis;
  var baseP = analysis.p;
  var perp = analysis.perp;
  if (!usePerp || !perp || !Number.isFinite(perp.pct)) {
    return Object.assign({}, analysis, { perpApplied: false, perpImpactPct: 0 });
  }
  var weight = perp.isSectorProxy ? 0.45 : 0.75;
  var cap = perp.isSectorProxy ? 4.0 : 6.0;
  var impact = Math.max(-cap, Math.min(cap, perp.pct * weight));
  // 과열 펀딩비 역방향 완충 (|펀딩비| > 0.05%)
  if (Number.isFinite(perp.funding) && Math.abs(perp.funding) > 0.05) {
    impact += perp.funding > 0 ? -0.45 : 0.45;
  }
  var adjP = Math.max(0.05, Math.min(0.95, baseP + impact / 100));
  var signal = { label: '중립 · 관망 구간', tone: 'slate' };
  if (adjP >= 0.62) signal = { label: '고확신 상승 우위', tone: 'teal' };
  else if (adjP <= 0.38) signal = { label: '고확신 하락 경계', tone: 'rose' };
  return Object.assign({}, analysis, {
    p: adjP,
    down: 1 - adjP,
    score: Math.round(adjP * 100),
    signal,
    perpApplied: true,
    perpImpactPct: Number(((adjP - baseP) * 100).toFixed(2))
  });
}

function applyWeekendOilOverlay(forecast, clPct, isWeekend, enabled) {
  if (!forecast || !enabled || !isWeekend || !Number.isFinite(clPct) || Math.abs(clPct) < 1.0) {
    return forecast ? Object.assign({}, forecast, { weekendOilApplied: false, weekendOilImpactPct: 0 }) : forecast;
  }
  // 주말 유가 급등은 증시 부담(-), 급락은 안도(+)로 완만하게 반영 (최대 ±3.5%p)
  var impact = Math.max(-3.5, Math.min(3.5, -clPct * 0.45));
  var adjP = Math.max(0.05, Math.min(0.95, forecast.p + impact / 100));
  return Object.assign({}, forecast, {
    p: adjP,
    down: 1 - adjP,
    score: Math.round(adjP * 100),
    weekendOilApplied: true,
    weekendOilImpactPct: Number(((adjP - forecast.p) * 100).toFixed(2))
  });
}
