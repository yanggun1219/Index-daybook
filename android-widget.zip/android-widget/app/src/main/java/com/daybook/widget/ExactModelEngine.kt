package com.daybook.widget

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.*

object ExactModelEngine {

    private const val MIN_BASE_SAMPLES = 18
    private const val MIN_EXTRA_SAMPLES = 60
    private const val RECENCY_HALF_LIFE = 380.0

    data class MarketRow(
        val date: String,
        val epochDay: Long,
        val close: Double,
        val ret: Double,
        val fx: Double,
        val breadth: Double,
        val flow: Double
    )

    data class BaseFeat(
        val feats: DoubleArray,
        val vol: Double,
        val ret1: Double,
        val ret20: Double,
        val usRet: Double,
        val usDate: String?
    )

    data class Sample(
        val x: DoubleArray,
        val vol: Double,
        val y: Double,
        val up: Double,
        val extra: Map<String, Double>
    )

    data class LogModel(
        val n: Int,
        val baseRate: Double,
        val means: DoubleArray,
        val stds: DoubleArray,
        val b: Double,
        val w: DoubleArray
    )

    data class ForecastOut(
        val p: Double,
        val active: Set<String>
    )

    data class WidgetResult(
        val updatedKst: String,
        val items: List<DaybookWidgetProvider.CardItem>
    )

    private fun parseEpochDay(s: String): Long {
        return try {
            LocalDate.parse(s.take(10)).toEpochDay()
        } catch (_: Exception) {
            0L
        }
    }

    private fun optFinite(arr: JSONArray, idx: Int): Double {
        if (idx >= arr.length() || arr.isNull(idx)) return Double.NaN
        val v = arr.optDouble(idx, Double.NaN)
        return if (v.isFinite()) v else Double.NaN
    }

    private fun parseRows(arr: JSONArray?): MutableList<MarketRow> {
        val out = mutableListOf<MarketRow>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val r = arr.optJSONArray(i) ?: continue
            val d = r.optString(0, "")
            if (d.length < 10) continue
            out.add(
                MarketRow(
                    date = d,
                    epochDay = parseEpochDay(d),
                    close = r.optDouble(1, 0.0),
                    ret = r.optDouble(2, 0.0),
                    fx = optFinite(r, 3),
                    breadth = optFinite(r, 4),
                    flow = optFinite(r, 5)
                )
            )
        }
        return out
    }

    private fun parsePairSeries(arr: JSONArray?): List<Pair<String, Double>> {
        val out = mutableListOf<Pair<String, Double>>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val r = arr.optJSONArray(i) ?: continue
            val d = r.optString(0, "")
            val v = optFinite(r, 1)
            if (d.isNotEmpty() && v.isFinite()) out.add(Pair(d, v))
        }
        return out
    }

    private fun adjacent(a: MarketRow?, b: MarketRow?): Boolean {
        if (a == null || b == null || a.close == 0.0) return false
        return (b.epochDay - a.epochDay) <= 7L && abs((b.close / a.close - 1.0) * 100.0 - b.ret) < 0.012
    }

    private fun sigmoid(z: Double): Double {
        if (z > 20.0) return 1.0
        if (z < -20.0) return 0.0
        return 1.0 / (1.0 + exp(-z))
    }

    private fun findLastIndexOnOrBefore(rows: List<MarketRow>, dateStr: String): Int {
        var lo = 0
        var hi = rows.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (rows[mid].date <= dateStr) {
                ans = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        return ans
    }

    private fun cumulativeUsReturn(nasdaqRows: List<MarketRow>, prevKrDate: String?, curKrDate: String): Pair<Double, String?> {
        val curIdx = findLastIndexOnOrBefore(nasdaqRows, curKrDate)
        if (curIdx < 0) return Pair(0.0, null)
        val prevIdx = if (prevKrDate != null) findLastIndexOnOrBefore(nasdaqRows, prevKrDate) else curIdx - 1
        if (prevIdx >= 0 && curIdx > prevIdx && curIdx - prevIdx <= 5 && nasdaqRows[prevIdx].close != 0.0) {
            val cumRet = (nasdaqRows[curIdx].close / nasdaqRows[prevIdx].close - 1.0) * 100.0
            return Pair(cumRet, nasdaqRows[curIdx].date)
        }
        return Pair(nasdaqRows[curIdx].ret, nasdaqRows[curIdx].date)
    }

    private fun buildDiffMap(series: List<Pair<String, Double>>, isPct: Boolean): Map<String, Double> {
        val map = HashMap<String, Double>(series.size)
        for (i in 1 until series.size) {
            val prev = series[i - 1].second
            val cur = series[i].second
            if (cur.isFinite() && prev.isFinite() && prev != 0.0) {
                map[series[i].first] = if (isPct) (cur / prev - 1.0) * 100.0 else cur - prev
            }
        }
        return map
    }

    private fun extractBaseFeatures(rows: List<MarketRow>, i: Int, marketKey: String, nasdaqRows: List<MarketRow>): BaseFeat? {
        if (i < 5) return null
        val today = rows[i]
        val prev = rows[i - 1]
        if (!adjacent(prev, today)) return null

        val ret5 = if (rows[i - 5].close != 0.0) (today.close / rows[i - 5].close - 1.0) * 100.0 else 0.0
        val ret20 = if (i >= 20 && rows[i - 20].close != 0.0) (today.close / rows[i - 20].close - 1.0) * 100.0 else Double.NaN
        val winStart = max(0, i - 9)
        val cnt = i - winStart + 1
        var sumR = 0.0
        for (k in winStart..i) sumR += rows[k].ret
        val meanR = sumR / cnt
        var varSum = 0.0
        for (k in winStart..i) {
            val df = rows[k].ret - meanR
            varSum += df * df
        }
        val volRaw = sqrt(varSum / max(1, cnt - 1))
        val vol10 = if (volRaw > 0.0) volRaw else 1.0

        return if (marketKey == "NASDAQ") {
            BaseFeat(doubleArrayOf(today.ret, prev.ret, ret5, vol10), vol10, today.ret, ret20, 0.0, null)
        } else {
            val fxChg = if (today.fx.isFinite() && prev.fx.isFinite() && prev.fx != 0.0) (today.fx / prev.fx - 1.0) * 100.0 else 0.0
            val (usRet, usDate) = cumulativeUsReturn(nasdaqRows, prev.date, today.date)
            BaseFeat(doubleArrayOf(today.ret, prev.ret, ret5, vol10, fxChg, usRet), vol10, today.ret, ret20, usRet, usDate)
        }
    }

    private fun fitLogisticModel(pool: List<Sample>, d: Int, useRecency: Boolean, l2Floor: Double): LogModel {
        val n = pool.size
        val sw = DoubleArray(n)
        var wSum = 0.0
        val decay = if (useRecency) ln(2.0) / RECENCY_HALF_LIFE else 0.0
        for (i in 0 until n) {
            val wt = if (useRecency) exp(-decay * (n - 1 - i)) else 1.0
            sw[i] = wt
            wSum += wt
        }
        val normFactor = n.toDouble() / wSum
        var upSum = 0.0
        for (i in 0 until n) {
            sw[i] *= normFactor
            upSum += sw[i] * pool[i].up
        }
        val baseRate = upSum / n

        val means = DoubleArray(d)
        val stds = DoubleArray(d)
        for (j in 0 until d) {
            var s = 0.0
            for (i in 0 until n) s += sw[i] * pool[i].x[j]
            val m = s / n
            var v = 0.0
            for (i in 0 until n) {
                val diff = pool[i].x[j] - m
                v += sw[i] * diff * diff
            }
            means[j] = m
            val sd = sqrt(v / n)
            stds[j] = if (sd > 0.0) sd else 1.0
        }

        val flatX = DoubleArray(n * d)
        for (i in 0 until n) {
            val rx = pool[i].x
            val off = i * d
            for (j in 0 until d) {
                val z = (rx[j] - means[j]) / stds[j]
                flatX[off + j] = if (z > 3.0) 3.0 else if (z < -3.0) -3.0 else z
            }
        }

        val baseLambda = max(l2Floor, (280.0 / sqrt(n.toDouble())) * sqrt(d.toDouble() / 6.0))
        val clampedBase = max(0.05, min(0.95, baseRate))
        var b = ln(clampedBase / (1.0 - clampedBase))
        val w = DoubleArray(d)
        val gw = DoubleArray(d)
        val lr = 0.08
        val invN = 1.0 / n
        val regTerm = baseLambda * invN

        for (iter in 0 until 110) {
            var gb = 0.0
            for (j in 0 until d) gw[j] = 0.0
            for (i in 0 until n) {
                val off = i * d
                var z = b
                for (j in 0 until d) z += w[j] * flatX[off + j]
                val err = sw[i] * (sigmoid(z) - pool[i].up)
                gb += err
                for (j in 0 until d) gw[j] += err * flatX[off + j]
            }
            b -= lr * (gb * invN)
            for (j in 0 until d) {
                w[j] -= lr * (gw[j] * invN + regTerm * w[j])
            }
        }
        return LogModel(n, baseRate, means, stds, b, w)
    }

    private fun predictProb(model: LogModel, rawFeats: DoubleArray): Double {
        var zNow = model.b
        for (j in rawFeats.indices) {
            val z = max(-3.0, min(3.0, (rawFeats[j] - model.means[j]) / model.stds[j]))
            zNow += model.w[j] * z
        }
        val rawP = sigmoid(zNow)
        val trust = model.n.toDouble() / (model.n + 60.0)
        return trust * rawP + (1.0 - trust) * model.baseRate
    }

    private fun detectPhase(marketKey: String): Pair<String, Double> {
        val now = Instant.now()
        return if (marketKey != "NASDAQ") {
            val kst = now.atOffset(ZoneOffset.ofHours(9))
            val dow = kst.dayOfWeek.value // 1=Mon..7=Sun
            val mins = kst.hour * 60 + kst.minute
            if (dow in 1..5 && mins in 540 until 930) {
                val prog = max(0.05, min(0.95, (mins - 540.0) / 390.0))
                Pair("intraday", prog)
            } else {
                Pair("preopen", 0.0)
            }
        } else {
            val utc = now.atOffset(ZoneOffset.UTC)
            val m = utc.monthValue
            val etOff = if (m in 4..10) -4 else -5
            val et = now.atOffset(ZoneOffset.ofHours(etOff))
            val dow = et.dayOfWeek.value
            val mins = et.hour * 60 + et.minute
            if (dow in 1..5 && mins in 570 until 960) {
                val prog = max(0.05, min(0.95, (mins - 570.0) / 390.0))
                Pair("intraday", prog)
            } else {
                Pair("preopen", 0.0)
            }
        }
    }

    private fun classifyPhaseSignal(p: Double, marketKey: String): Pair<String, String> {
        val thr = if (marketKey == "NASDAQ") 0.58 else 0.60
        if (p >= thr) return Pair("HIGH_UP", "상승 예정")
        if (p <= 1.0 - thr) return Pair("HIGH_DOWN", "하락 예정")
        return Pair("NEUTRAL", "관망 구간")
    }

    fun compute(dataJsText: String, liveJsonText: String): WidgetResult {
        val sIdx = dataJsText.indexOf('{')
        val eIdx = dataJsText.lastIndexOf('}')
        if (sIdx < 0 || eIdx <= sIdx) throw Exception("data.js 형식 오류")
        val markets = JSONObject(dataJsText.substring(sIdx, eIdx + 1))

        val live = try { JSONObject(liveJsonText) } catch (_: Exception) { JSONObject() }
        val kospiRows = parseRows(markets.optJSONArray("KOSPI"))
        val nasdaqRows = parseRows(markets.optJSONArray("NASDAQ"))

        // Merge live KOSPI / USDKRW exactly like app.js
        val dateKst = live.optString("dateKst", "")
        val liveIndices = live.optJSONObject("indices")
        val fxNow = liveIndices?.optDouble("USDKRW", Double.NaN) ?: Double.NaN
        val liveKs = liveIndices?.optJSONObject("KOSPI")
        if (liveKs != null && kospiRows.isNotEmpty()) {
            val liveClose = liveKs.optDouble("close", Double.NaN)
            val livePct = liveKs.optDouble("pct", 0.0)
            if (liveClose.isFinite()) {
                val last = kospiRows.last()
                val useFx = if (fxNow.isFinite()) fxNow else last.fx
                if (last.date == dateKst) {
                    kospiRows[kospiRows.lastIndex] = MarketRow(dateKst, parseEpochDay(dateKst), liveClose, livePct, useFx, last.breadth, last.flow)
                } else if (dateKst.isNotEmpty() && dateKst > last.date && abs(liveClose - last.close) > 0.005) {
                    val calcPct = ((liveClose / last.close - 1.0) * 100.0 * 100.0).roundToInt() / 100.0
                    kospiRows.add(MarketRow(dateKst, parseEpochDay(dateKst), liveClose, calcPct, useFx, Double.NaN, Double.NaN))
                }
            }
        }

        // Build macro maps
        val soxMap = parsePairSeries(markets.optJSONArray("SOX")).toMap()
        val soxSpreads = HashMap<String, Double>()
        for (i in 1 until nasdaqRows.size) {
            val d = nasdaqRows[i].date
            val prev = soxMap[nasdaqRows[i - 1].date]
            val cur = soxMap[d]
            if (prev != null && cur != null && prev > 0.0 && cur > 0.0) {
                soxSpreads[d] = (cur / prev - 1.0) * 100.0 - nasdaqRows[i].ret
            }
        }
        val vixMap = parsePairSeries(markets.optJSONArray("VIX")).toMap()
        val vix3mMap = parsePairSeries(markets.optJSONArray("VIX3M")).toMap()
        val tnxDiff = buildDiffMap(parsePairSeries(markets.optJSONArray("TNX")), false)
        val dxyPct = buildDiffMap(parsePairSeries(markets.optJSONArray("DXY")), true)
        val oilPct = buildDiffMap(parsePairSeries(markets.optJSONArray("CL")), true)
        val goldPct = buildDiffMap(parsePairSeries(markets.optJSONArray("GC")), true)
        val daxPct = buildDiffMap(parsePairSeries(markets.optJSONArray("DAX")), true)
        val newsMap = parsePairSeries(markets.optJSONArray("NEWS_HIST")).toMap()

        val krFutMap = HashMap<String, Double>()
        val krBasisMap = HashMap<String, Double>()
        val krFutArr = markets.optJSONArray("KR_FUT_HIST")
        if (krFutArr != null) {
            for (i in 0 until krFutArr.length()) {
                val r = krFutArr.optJSONArray(i) ?: continue
                val d = r.optString(0, "")
                val f1 = optFinite(r, 1)
                val f2 = optFinite(r, 2)
                if (d.isNotEmpty() && f1.isFinite()) krFutMap[d] = f1
                if (d.isNotEmpty() && f2.isFinite()) krBasisMap[d] = f2
            }
        }

        val kospiByDate = HashMap<String, Double>(kospiRows.size)
        for (r in kospiRows) kospiByDate[r.date] = r.ret

        fun findPreUsKoreaRet(nasdaqDate: String, nextNasdaqDate: String?): Double {
            if (nextNasdaqDate != null) {
                return kospiByDate[nextNasdaqDate] ?: Double.NaN
            }
            val nEpoch = parseEpochDay(nasdaqDate)
            for (i in kospiRows.size - 1 downTo 0) {
                val kr = kospiRows[i]
                if (kr.date <= nasdaqDate) break
                val gap = kr.epochDay - nEpoch
                if (gap in 1..5) return kr.ret
            }
            return Double.NaN
        }

        fun makeExtra(refUsDate: String?, breadth: Double, flow: Double, cur: BaseFeat, key: String, nextUsDate: String?, curDate: String): Map<String, Double> {
            val m = HashMap<String, Double>()
            val vixVal = if (refUsDate != null) vixMap[refUsDate] ?: Double.NaN else Double.NaN
            val vix3mVal = if (refUsDate != null) vix3mMap[refUsDate] ?: Double.NaN else Double.NaN
            val vixRatio = if (vixVal.isFinite() && vix3mVal.isFinite() && vix3mVal > 0.0) vixVal / vix3mVal else Double.NaN
            val usVix = if (vixVal.isFinite() && cur.usRet.isFinite()) cur.usRet * (vixVal / 20.0) else Double.NaN

            if (refUsDate != null) {
                soxSpreads[refUsDate]?.let { m["sox"] = it }
                tnxDiff[refUsDate]?.let { m["tnx"] = it }
                dxyPct[refUsDate]?.let { m["dxy"] = it }
                oilPct[refUsDate]?.let { m["oil"] = it }
                goldPct[refUsDate]?.let { m["gold"] = it }
                daxPct[refUsDate]?.let { m["dax"] = it }
            }
            if (breadth.isFinite()) m["breadth"] = breadth
            if (flow.isFinite()) m["flow"] = flow
            if (vixVal.isFinite()) m["vix"] = vixVal
            if (vixRatio.isFinite()) m["vixRatio"] = vixRatio
            if (usVix.isFinite()) m["usVix"] = usVix
            if (cur.ret20.isFinite()) m["ret20"] = cur.ret20

            val nVal = newsMap[curDate] ?: (if (refUsDate != null) newsMap[refUsDate] else null)
            if (nVal != null && nVal.isFinite()) m["news"] = nVal
            val kfVal = krFutMap[curDate] ?: (if (refUsDate != null) krFutMap[refUsDate] else null)
            if (kfVal != null && kfVal.isFinite()) m["krFut"] = kfVal
            val kbVal = krBasisMap[curDate] ?: (if (refUsDate != null) krBasisMap[refUsDate] else null)
            if (kbVal != null && kbVal.isFinite()) m["krBasis"] = kbVal

            if (key == "NASDAQ" && refUsDate != null) {
                val krRet = findPreUsKoreaRet(refUsDate, nextUsDate)
                if (krRet.isFinite()) {
                    m["krLead"] = krRet
                    m["krResid"] = if (cur.ret1.isFinite()) krRet - 0.55 * cur.ret1 else krRet
                }
            }
            return m
        }

        val liveNewsObj = live.optJSONObject("news") ?: markets.optJSONObject("NEWS")
        val liveNewsScore = liveNewsObj?.optDouble("sentiment", 0.0)?.let { if (it.isFinite()) it else 0.0 } ?: 0.0
        val futObj = live.optJSONObject("futures") ?: markets.optJSONObject("FUTURES") ?: JSONObject()
        val liveKrFut = futObj.optDouble("K200_pct", 0.0).let { if (it.isFinite()) it else 0.0 }
        val liveKrBasis = futObj.optDouble("K200_basis", 0.0).let { if (it.isFinite()) it else 0.0 }
        val clPct = futObj.optDouble("CL_pct", Double.NaN)
        val clWeekend = futObj.optBoolean("CL_weekend", false)
        val ewyPct = futObj.optDouble("EWY_pct", Double.NaN)
        val nqPct = futObj.optDouble("NQ_pct", Double.NaN)
        val esPct = futObj.optDouble("ES_pct", Double.NaN)
        val liveKsOpen = liveIndices?.optJSONObject("KOSPI")?.optDouble("open", Double.NaN) ?: Double.NaN
        val liveNqOpen = liveIndices?.optJSONObject("NASDAQ")?.optDouble("open", Double.NaN) ?: Double.NaN

        fun evalMarket(rows: List<MarketRow>, key: String, koName: String): DaybookWidgetProvider.CardItem {
            var lv = -1
            for (i in 24 until rows.size) {
                if (adjacent(rows[i - 1], rows[i])) lv = i
            }
            if (lv < 0) {
                return DaybookWidgetProvider.CardItem(koName, "NEUTRAL", "표본 대기", "-", 0.0, emptyList())
            }
            val current = extractBaseFeatures(rows, lv, key, nasdaqRows)
                ?: return DaybookWidgetProvider.CardItem(koName, "NEUTRAL", "표본 대기", "-", 0.0, emptyList())

            val candidates = if (key == "NASDAQ") {
                listOf("krLead", "krResid", "vixRatio", "dax", "vix", "tnx", "dxy", "news")
            } else {
                listOf("sox", "vix", "usVix", "flow", "oil", "gold", "krFut", "krBasis", "news")
            }
            val useRecency = (key == "KOSPI")
            val l2Floor = if (key == "NASDAQ") 55.0 else 10.0

            val pool = ArrayList<Sample>(lv)
            for (i in 5..lv - 1) {
                val f = extractBaseFeatures(rows, i, key, nasdaqRows) ?: continue
                if (!adjacent(rows[i], rows[i + 1])) continue
                val y = rows[i + 1].ret
                val r = rows[i]
                val nextUsDate = if (i + 1 < rows.size) rows[i + 1].date else null
                val refUs = if (key == "NASDAQ") r.date else f.usDate
                pool.add(Sample(f.feats, f.vol, y, if (y > 0.0) 1.0 else 0.0, makeExtra(refUs, r.breadth, r.flow, f, key, nextUsDate, r.date)))
            }
            if (pool.size < MIN_BASE_SAMPLES) {
                return DaybookWidgetProvider.CardItem(koName, "NEUTRAL", "표본 대기", "-", 0.0, emptyList())
            }

            val curRow = rows[lv]
            val nextUs = if (lv + 1 < rows.size) rows[lv + 1].date else null
            val refUs = if (key == "NASDAQ") curRow.date else current.usDate
            val curExtra = makeExtra(refUs, curRow.breadth, curRow.flow, current, key, nextUs, curRow.date)

            // Select active extras
            val minReq = max(MIN_EXTRA_SAMPLES, ceil(pool.size * 0.72).toInt())
            val qualifying = candidates.filter { k ->
                val cv = curExtra[k]
                if (cv == null || !cv.isFinite()) return@filter false
                var cnt = 0
                for (s in pool) {
                    val sv = s.extra[k]
                    if (sv != null && sv.isFinite()) cnt++
                }
                cnt >= minReq
            }

            var activeKeys: List<String> = emptyList()
            var eligible: List<Sample> = pool
            if (qualifying.isNotEmpty()) {
                val joint = pool.filter { s -> qualifying.all { k -> val v = s.extra[k]; v != null && v.isFinite() } }
                if (joint.size >= minReq) {
                    activeKeys = qualifying
                    eligible = joint
                } else {
                    val first = listOf(qualifying[0])
                    activeKeys = first
                    eligible = pool.filter { s -> val v = s.extra[first[0]]; v != null && v.isFinite() }
                }
            }

            var pVal: Double
            if (activeKeys.isNotEmpty()) {
                val isNasdaqLeadOnly = (key == "NASDAQ" && activeKeys.contains("krLead"))
                val baseLen = if (isNasdaqLeadOnly) 0 else current.feats.size
                val dTotal = baseLen + activeKeys.size
                val train = eligible.map { row ->
                    val arr = DoubleArray(dTotal)
                    if (!isNasdaqLeadOnly) System.arraycopy(row.x, 0, arr, 0, baseLen)
                    for (kIdx in activeKeys.indices) arr[baseLen + kIdx] = row.extra[activeKeys[kIdx]] ?: 0.0
                    Sample(arr, row.vol, row.y, row.up, row.extra)
                }
                val nowArr = DoubleArray(dTotal)
                if (!isNasdaqLeadOnly) System.arraycopy(current.feats, 0, nowArr, 0, baseLen)
                for (kIdx in activeKeys.indices) nowArr[baseLen + kIdx] = curExtra[activeKeys[kIdx]] ?: 0.0
                val extModel = fitLogisticModel(train, dTotal, useRecency, l2Floor)
                pVal = predictProb(extModel, nowArr)
            } else {
                val baseModel = fitLogisticModel(pool, current.feats.size, useRecency, l2Floor)
                pVal = predictProb(baseModel, current.feats)
            }

            // Apply live news overlay
            val activeSet = activeKeys.toSet()
            val clampedScore = max(-100.0, min(100.0, liveNewsScore))
            if (!activeSet.contains("news") && clampedScore != 0.0) {
                val pc = max(0.02, min(0.98, pVal))
                pVal = sigmoid(ln(pc / (1.0 - pc)) + (clampedScore / 100.0) * 0.18)
            }

            // Apply K200 futures overlay (KOSPI only)
            if (key != "NASDAQ" && !activeSet.contains("krFut")) {
                val pct = max(-6.0, min(6.0, liveKrFut))
                val basis = max(-5.0, min(5.0, liveKrBasis))
                if (pct != 0.0 || basis != 0.0) {
                    val pc = max(0.02, min(0.98, pVal))
                    val dLogit = max(-0.28, min(0.28, pct * 0.10 + basis * 0.02))
                    pVal = sigmoid(ln(pc / (1.0 - pc)) + dLogit)
                }
            }

            // Apply weekend oil overlay
            if (clWeekend && clPct.isFinite() && abs(clPct) >= 1.0) {
                val impact = max(-3.5, min(3.5, -clPct * 0.45))
                pVal = max(0.05, min(0.95, pVal + impact / 100.0))
            }

            val (phase, progress) = detectPhase(key)
            val todayOpen = if (key == "NASDAQ") liveNqOpen else liveKsOpen
            if (phase == "preopen") {
                var dLogit = 0.0
                if (key != "NASDAQ") {
                    if (ewyPct.isFinite() && abs(ewyPct) >= 0.15) dLogit += max(-0.55, min(0.55, ewyPct * 0.22))
                    if (nqPct.isFinite() && abs(nqPct) >= 0.15) dLogit += max(-0.40, min(0.40, nqPct * 0.16))
                } else {
                    if (nqPct.isFinite() && abs(nqPct) >= 0.10) dLogit += max(-0.65, min(0.65, nqPct * 0.28))
                    if (esPct.isFinite() && abs(esPct) >= 0.10) dLogit += max(-0.30, min(0.30, esPct * 0.14))
                }
                val pc = max(0.03, min(0.97, pVal))
                pVal = sigmoid(ln(pc / (1.0 - pc)) + dLogit)
            } else if (todayOpen.isFinite() && todayOpen > 0.0) {
                val openDiffPct = (curRow.close / todayOpen - 1.0) * 100.0
                val remVol = max(0.25, max(0.4, current.vol) * sqrt(max(0.08, 1.0 - progress)))
                val pOpen = sigmoid((openDiffPct / remVol) * 1.35)
                val wOpen = 0.35 + 0.55 * progress
                pVal = wOpen * pOpen + (1.0 - wOpen) * pVal
            }
            pVal = max(0.04, min(0.96, pVal))

            val (sigCode, sigLabel) = classifyPhaseSignal(pVal, key)
            val phaseTag = if (phase == "intraday") "종가(시가대비)" else "다음 시초가"
            val openSub = if (todayOpen.isFinite() && todayOpen > 0.0) {
                val dp = (curRow.close / todayOpen - 1.0) * 100.0
                String.format("시가 %,.1f (%s%.2f%%)", todayOpen, if (dp > 0) "+" else "", dp)
            } else {
                if (phase == "intraday") "장중 실시간" else "야간 선행 반영"
            }
            val sp = mutableListOf<Double>()
            for (k in max(0, lv - 19)..lv) sp.add(rows[k].close)
            val priceStr = String.format("%,.2f", curRow.close)
            val dirScore = max(-100, min(100, ((pVal - 0.5) * 200.0).roundToInt()))
            return DaybookWidgetProvider.CardItem(koName, sigCode, sigLabel, priceStr, curRow.ret, sp, phaseTag, openSub, dirScore, 0)
        }

        val rawStamp = live.optString("updatedKst", "")
        val stamp = if (rawStamp.length >= 16) rawStamp.substring(5, 16) + " KST" else "종가 기준"
        val items = listOf(
            evalMarket(kospiRows, "KOSPI", "코스피"),
            evalMarket(nasdaqRows, "NASDAQ", "나스닥")
        )
        return WidgetResult(stamp, items)
    }
}
