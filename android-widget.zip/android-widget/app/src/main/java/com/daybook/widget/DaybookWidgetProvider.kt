package com.daybook.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class DaybookWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.daybook.widget.ACTION_REFRESH"
        const val PREFS_NAME = "daybook_widget_prefs"
        const val KEY_WORKER_URL = "worker_url"
        const val WEB_APP_URL = "https://yanggun1219.github.io/Index-daybook/"

        fun triggerUpdate(context: Context) {
            val intent = Intent(context, DaybookWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllAsync(context, appWidgetManager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, DaybookWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                updateAllAsync(context, mgr, ids)
            }
        }
    }

    private fun updateAllAsync(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pendingResult = goAsync()
        Thread {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val baseUrl = (prefs.getString(KEY_WORKER_URL, "") ?: "").trim().trimEnd('/')
                val views = RemoteViews(context.packageName, R.layout.widget_daybook)

                // Tap refresh button -> refresh widget
                val refreshIntent = Intent(context, DaybookWidgetProvider::class.java).apply {
                    action = ACTION_REFRESH
                }
                val refreshPi = PendingIntent.getBroadcast(
                    context, 1001, refreshIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_refresh, refreshPi)

                // Tap title -> open full web app
                val openWebIntent = Intent(Intent.ACTION_VIEW, Uri.parse(WEB_APP_URL))
                val openWebPi = PendingIntent.getActivity(
                    context, 1002, openWebIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, openWebPi)

                if (baseUrl.isEmpty()) {
                    views.setTextViewText(R.id.widget_updated, "앱에서 Workers 주소 입력")
                    for (id in ids) mgr.updateAppWidget(id, views)
                    return@Thread
                }

                views.setTextViewText(R.id.widget_updated, "갱신 중...")
                for (id in ids) mgr.updateAppWidget(id, views)

                val conn = (URL("$baseUrl/widget").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 12000
                    setRequestProperty("User-Agent", "IndexDaybookWidget/1.0")
                }

                val code = conn.responseCode
                if (code == 200) {
                    val text = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(text)
                    val updated = json.optString("updatedKst", "완료")
                    views.setTextViewText(R.id.widget_updated, updated)

                    val items = json.optJSONArray("items")
                    val nameIds = intArrayOf(R.id.t0_name, R.id.t1_name, R.id.t2_name, R.id.t3_name)
                    val badgeIds = intArrayOf(R.id.t0_badge, R.id.t1_badge, R.id.t2_badge, R.id.t3_badge)
                    val probIds = intArrayOf(R.id.t0_prob, R.id.t1_prob, R.id.t2_prob, R.id.t3_prob)
                    val retIds = intArrayOf(R.id.t0_ret, R.id.t1_ret, R.id.t2_ret, R.id.t3_ret)
                    val barIds = intArrayOf(R.id.t0_bar, R.id.t1_bar, R.id.t2_bar, R.id.t3_bar)
                    val priceIds = intArrayOf(R.id.t0_price, R.id.t1_price, R.id.t2_price, R.id.t3_price)

                    val upColor = Color.parseColor("#FB7185")
                    val downColor = Color.parseColor("#60A5FA")
                    val mutedColor = Color.parseColor("#94A3B8")

                    if (items != null) {
                        for (i in 0 until minOf(4, items.length())) {
                            val it = items.getJSONObject(i)
                            val name = it.optString("name", "-")
                            val p = it.optDouble("p", 50.0)
                            val ret = it.optDouble("ret", 0.0)
                            val price = it.optString("price", "-")
                            val badge = it.optString("badge", "관망")

                            views.setTextViewText(nameIds[i], name)
                            views.setTextViewText(badgeIds[i], badge)
                            views.setTextColor(
                                badgeIds[i],
                                if (badge.contains("상승")) upColor else if (badge.contains("하락")) downColor else mutedColor
                            )
                            views.setTextViewText(probIds[i], String.format("%.1f%%", p))
                            views.setTextColor(probIds[i], if (p >= 50.0) upColor else downColor)

                            val retStr = String.format("%s%.2f%%", if (ret > 0) "+" else "", ret)
                            views.setTextViewText(retIds[i], retStr)
                            views.setTextColor(retIds[i], if (ret >= 0) upColor else downColor)

                            views.setProgressBar(barIds[i], 100, p.toInt().coerceIn(0, 100), false)
                            views.setTextViewText(priceIds[i], price)
                        }
                    }
                } else {
                    views.setTextViewText(R.id.widget_updated, "오류 HTTP $code")
                }
                for (id in ids) mgr.updateAppWidget(id, views)
            } catch (e: Exception) {
                val views = RemoteViews(context.packageName, R.layout.widget_daybook)
                views.setTextViewText(R.id.widget_updated, "연결 지연")
                for (id in ids) mgr.updateAppWidget(id, views)
            } finally {
                pendingResult.finish()
            }
        }.start()
    }
}
