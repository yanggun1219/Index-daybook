package com.daybook.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class DaybookWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.daybook.widget.ACTION_REFRESH"
        const val PREFS_NAME = "daybook_widget_prefs"
        const val KEY_WORKER_URL = "worker_url"
        const val KEY_DARK_MODE = "dark_mode"
        const val WEB_APP_URL = "https://yanggun1219.github.io/Index-daybook/"
        const val DEFAULT_WORKER_URL = "https://index-daybook-live.yanggun1219.workers.dev"

        fun normalizeWorkerUrl(raw: String): String {
            var u = raw.trim()
            val idx = u.indexOf("worker=")
            if (idx >= 0) {
                u = u.substring(idx + 7).substringBefore("&")
                try { u = Uri.decode(u) } catch (_: Exception) {}
            }
            u = u.trim().trimEnd('/')
            if (u.endsWith("/widget")) u = u.removeSuffix("/widget")
            if (u.endsWith("/live")) u = u.removeSuffix("/live")
            return u.trimEnd('/')
        }

        fun triggerUpdate(context: Context) {
            val intent = Intent(context, DaybookWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllAsync(context, appWidgetManager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, DaybookWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                updateAllAsync(context, mgr, ids)
            }
        }
    }

    private fun updateAllAsync(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pendingResult = goAsync()
        Thread {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val isDark = prefs.getBoolean(KEY_DARK_MODE, false)
            val layoutId = if (isDark) R.layout.widget_daybook_dark else R.layout.widget_daybook
            val views = RemoteViews(context.packageName, layoutId)

            // Header refresh button -> refresh news
            val refreshIntent = Intent(context, DaybookWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            val refreshPi = PendingIntent.getBroadcast(
                context, 1001, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_refresh, refreshPi)

            // Tap header title -> open Index Daybook web app
            val openAppPi = PendingIntent.getActivity(
                context, 1002, Intent(Intent.ACTION_VIEW, Uri.parse(WEB_APP_URL)),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_title, openAppPi)

            try {
                val rawSaved = prefs.getString(KEY_WORKER_URL, "") ?: ""
                val baseUrl = normalizeWorkerUrl(if (rawSaved.isBlank()) DEFAULT_WORKER_URL else rawSaved)

                val conn = (URL("$baseUrl/live").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 7000
                    readTimeout = 7000
                    setRequestProperty("User-Agent", "IndexDaybookNewsWidget/5.0")
                }
                val code = conn.responseCode
                val body = try {
                    if (code != 200) throw Exception("HTTP $code")
                    conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                } finally {
                    conn.disconnect()
                }

                val json = JSONObject(body)
                val updatedRaw = json.optString("updatedKst", "")
                val stamp = if (updatedRaw.length >= 16) updatedRaw.substring(11, 16) else "방금"
                views.setTextViewText(R.id.widget_updated, stamp)

                val newsObj = json.optJSONObject("news")
                val sentiment = newsObj?.optInt("sentiment", 0) ?: 0
                val upCol = Color.parseColor(if (isDark) "#FF5A6E" else "#E11D48")
                val downCol = Color.parseColor(if (isDark) "#4DA3FF" else "#2563EB")
                val flatCol = Color.parseColor(if (isDark) "#94A3B8" else "#64748B")

                val (sentText, sentCol) = when {
                    sentiment >= 10 -> Pair("온도 +$sentiment 긍정", upCol)
                    sentiment <= -10 -> Pair("온도 $sentiment 경계", downCol)
                    else -> Pair("온도 ${if (sentiment > 0) "+" else ""}$sentiment 중립", flatCol)
                }
                views.setTextViewText(R.id.widget_sentiment, sentText)
                views.setTextColor(R.id.widget_sentiment, sentCol)

                val items = newsObj?.optJSONArray("items")
                val rowIds = intArrayOf(R.id.news_row_0, R.id.news_row_1, R.id.news_row_2, R.id.news_row_3)
                val titleIds = intArrayOf(R.id.news_title_0, R.id.news_title_1, R.id.news_title_2, R.id.news_title_3)
                val metaIds = intArrayOf(R.id.news_meta_0, R.id.news_meta_1, R.id.news_meta_2, R.id.news_meta_3)

                for (i in 0 until 4) {
                    if (items != null && i < items.length()) {
                        val it = items.getJSONObject(i)
                        val title = it.optString("title", "").trim()
                        val source = it.optString("source", "").trim()
                        val url = it.optString("url", WEB_APP_URL).trim().ifEmpty { WEB_APP_URL }
                        views.setTextViewText(titleIds[i], title)
                        views.setTextViewText(metaIds[i], source)

                        val artIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        val artPi = PendingIntent.getActivity(
                            context, 2000 + i, artIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                        )
                        views.setOnClickPendingIntent(rowIds[i], artPi)
                    } else {
                        views.setTextViewText(titleIds[i], "-")
                        views.setTextViewText(metaIds[i], "")
                        views.setOnClickPendingIntent(rowIds[i], openAppPi)
                    }
                }
            } catch (e: Throwable) {
                views.setTextViewText(R.id.widget_updated, "재시도(↻)")
            } finally {
                for (id in ids) mgr.updateAppWidget(id, views)
                pendingResult.finish()
            }
        }.start()
    }
}
