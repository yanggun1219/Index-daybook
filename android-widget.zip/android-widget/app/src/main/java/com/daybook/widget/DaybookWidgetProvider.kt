package com.daybook.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.widget.RemoteViews
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class DaybookWidgetProvider : AppWidgetProvider() {

    data class CardItem(
        val name: String,
        val code: String,      // HIGH_UP, HIGH_DOWN, NEUTRAL
        val label: String,     // 고확신 상승 신호, 고확신 하락 경계, 중립 · 관망 구간
        val price: String,
        val ret: Double,
        val spark: List<Double>
    )

    companion object {
        const val ACTION_REFRESH = "com.daybook.widget.ACTION_REFRESH"
        const val PREFS_NAME = "daybook_widget_prefs"
        const val KEY_WORKER_URL = "worker_url"
        const val WEB_APP_URL = "https://yanggun1219.github.io/Index-daybook/"
        const val DATA_JS_URL = "https://yanggun1219.github.io/Index-daybook/data.js"
        const val DEFAULT_WORKER_URL = "https://index-daybook-live.yanggun1219.workers.dev"

        fun normalizeWorkerUrl(raw: String): String {
            var u = raw.trim()
            val idx = u.indexOf("worker=")
            if (idx >= 0) {
                u = u.substring(idx + 7).substringBefore("&")
                try { u = Uri.decode(u) } catch (_: Exception) {}
            }
            u = u.trim().trimEnd('/')
            if (u.endsWith("/widget")) u = u.removeSuffix("/widget")
            if (u.endsWith("/live")) u = u.removeSuffix("/live")
            return u.trimEnd('/')
        }

        fun triggerUpdate(context: Context) {
            val intent = Intent(context, DaybookWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllAsync(context, appWidgetManager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, DaybookWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                updateAllAsync(context, mgr, ids)
            }
        }
    }

    private fun httpGetText(urlStr: String, timeoutMs: Int = 10000): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            setRequestProperty("User-Agent", "IndexDaybookWidget/2.0")
        }
        if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode}")
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private fun updateAllAsync(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pendingResult = goAsync()
        Thread {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val rawSaved = prefs.getString(KEY_WORKER_URL, "") ?: ""
                val baseUrl = normalizeWorkerUrl(if (rawSaved.isBlank()) DEFAULT_WORKER_URL else rawSaved)

                val loadingViews = buildBaseViews(context)
                loadingViews.setImageViewBitmap(
                    R.id.widget_canvas,
                    renderWidgetBitmap(
                        updated = "동기화 중...",
                        items = listOf(
                            CardItem("코스피", "NEUTRAL", "계산 중", "-", 0.0, emptyList()),
                            CardItem("나스닥", "NEUTRAL", "계산 중", "-", 0.0, emptyList())
                        )
                    )
                )
                for (id in ids) mgr.updateAppWidget(id, loadingViews)

                // 1. Fetch data.js from GitHub Pages (with local cache fallback)
                val cacheFile = File(context.cacheDir, "data_cached.js")
                val dataJs = try {
                    val fetched = httpGetText("$DATA_JS_URL?t=${System.currentTimeMillis() / 60000}", 12000)
                    cacheFile.writeText(fetched, Charsets.UTF_8)
                    fetched
                } catch (e: Exception) {
                    if (cacheFile.exists()) cacheFile.readText(Charsets.UTF_8) else throw e
                }

                // 2. Fetch live JSON from Cloudflare Workers (/live)
                val liveJsonStr = try {
                    httpGetText("$baseUrl/live", 10000)
                } catch (_: Exception) {
                    "{}"
                }

                // 3. Run pure native Kotlin ExactModelEngine (~15ms, 100% identical to web app model.js)
                val res = ExactModelEngine.compute(dataJs, liveJsonStr)
                val views = buildBaseViews(context)
                views.setImageViewBitmap(R.id.widget_canvas, renderWidgetBitmap(res.updatedKst, res.items))
                for (id in ids) mgr.updateAppWidget(id, views)
            } catch (e: Exception) {
                val views = buildBaseViews(context)
                val msg = (e.message ?: "연결 지연").take(26)
                views.setImageViewBitmap(
                    R.id.widget_canvas,
                    renderWidgetBitmap(
                        updated = "오류: $msg",
                        items = listOf(
                            CardItem("코스피", "NEUTRAL", "재시도 필요", "-", 0.0, emptyList()),
                            CardItem("나스닥", "NEUTRAL", "재시도 필요", "-", 0.0, emptyList())
                        )
                    )
                )
                for (id in ids) mgr.updateAppWidget(id, views)
            } finally {
                pendingResult.finish()
            }
        }.start()
    }

    private fun buildBaseViews(context: Context): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_daybook)
        val refreshIntent = Intent(context, DaybookWidgetProvider::class.java).apply {
            action = ACTION_REFRESH
        }
        val refreshPi = PendingIntent.getBroadcast(
            context, 1001, refreshIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshPi)

        val openWebIntent = Intent(Intent.ACTION_VIEW, Uri.parse(WEB_APP_URL))
        val openWebPi = PendingIntent.getActivity(
            context, 1002, openWebIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, openWebPi)
        return views
    }

    private fun renderWidgetBitmap(updated: String, items: List<CardItem>): Bitmap {
        val w = 960
        val h = 460
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)

        // 1. Outer Obsidian Glass Card
        val outerRect = RectF(4f, 4f, w - 4f, h - 4f)
        p.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            Color.parseColor("#080E1C"),
            Color.parseColor("#0F1A30"),
            Shader.TileMode.CLAMP
        )
        c.drawRoundRect(outerRect, 44f, 44f, p)
        p.shader = null

        // Outer hairline border
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f
        p.color = Color.parseColor("#263854")
        c.drawRoundRect(outerRect, 44f, 44f, p)
        p.style = Paint.Style.FILL

        // 2. Top Header Bar
        // Glowing mint status dot
        p.shader = RadialGradient(48f, 48f, 20f, Color.parseColor("#662DD4BF"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(48f, 48f, 20f, p)
        p.shader = null
        p.color = Color.parseColor("#2DD4BF")
        c.drawCircle(48f, 48f, 8f, p)

        // App Title
        p.color = Color.parseColor("#2DD4BF")
        p.textSize = 28f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText("지수 관측소", 68f, 58f, p)

        // Timestamp
        p.color = Color.parseColor("#64748B")
        p.textSize = 22f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        c.drawText(updated, 232f, 56f, p)

        // Top-right circular refresh button
        val btnCx = w - 54f
        val btnCy = 48f
        p.color = Color.parseColor("#113E44")
        c.drawCircle(btnCx, btnCy, 28f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = Color.parseColor("#2DD4BF")
        c.drawCircle(btnCx, btnCy, 28f, p)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textSize = 30f
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText("↻", btnCx, btnCy + 11f, p)
        p.textAlign = Paint.Align.LEFT

        // 3. Two Large Glass Cards Side-by-Side
        val padX = 26f
        val gap = 20f
        val cardTop = 94f
        val cardBottom = h - 24f
        val cardW = (w - padX * 2 - gap) / 2f

        for (idx in 0 until minOf(2, items.size)) {
            val item = items[idx]
            val left = padX + idx * (cardW + gap)
            val right = left + cardW
            val rect = RectF(left, cardTop, right, cardBottom)
            drawGlassCard(c, rect, item)
        }

        return bmp
    }

    private fun drawGlassCard(c: Canvas, rect: RectF, item: CardItem) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
        val cx = rect.centerX()

        val (accent, glowHex, pillBg) = when (item.code) {
            "HIGH_UP" -> Triple(Color.parseColor("#FB7185"), "#40FB7185", Color.parseColor("#2DFB7185"))
            "HIGH_DOWN" -> Triple(Color.parseColor("#38BDF8"), "#4038BDF8", Color.parseColor("#2D38BDF8"))
            else -> Triple(Color.parseColor("#2DD4BF"), "#2B2DD4BF", Color.parseColor("#2494A3B8"))
        }
        val labelColor = if (item.code == "NEUTRAL") Color.parseColor("#CBD5E1") else accent

        // Card base fill
        p.shader = LinearGradient(
            rect.left, rect.top, rect.left, rect.bottom,
            Color.parseColor("#111C33"),
            Color.parseColor("#0B1324"),
            Shader.TileMode.CLAMP
        )
        c.drawRoundRect(rect, 32f, 32f, p)
        p.shader = null

        // Ambient radial glow clipped inside card
        c.save()
        val clipPath = Path().apply { addRoundRect(rect, 32f, 32f, Path.Direction.CW) }
        c.clipPath(clipPath)

        p.shader = RadialGradient(
            cx, rect.top + 110f, rect.width() * 0.62f,
            Color.parseColor(glowHex),
            Color.TRANSPARENT,
            Shader.TileMode.CLAMP
        )
        c.drawRect(rect, p)
        p.shader = null

        // Subtle 20-day sparkline at the bottom of the card
        if (item.spark.size >= 2) {
            val minV = item.spark.minOrNull() ?: 0.0
            val maxV = item.spark.maxOrNull() ?: 1.0
            val span = (maxV - minV).let { if (it < 1e-6) 1.0 else it }
            val spTop = rect.bottom - 94f
            val spBot = rect.bottom - 18f
            val spLeft = rect.left + 16f
            val spRight = rect.right - 16f
            val stepX = (spRight - spLeft) / (item.spark.size - 1).coerceAtLeast(1)

            val linePath = Path()
            val fillPath = Path()
            for (k in item.spark.indices) {
                val x = spLeft + k * stepX
                val norm = ((item.spark[k] - minV) / span).toFloat()
                val y = spBot - norm * (spBot - spTop)
                if (k == 0) {
                    linePath.moveTo(x, y)
                    fillPath.moveTo(x, rect.bottom)
                    fillPath.lineTo(x, y)
                } else {
                    linePath.lineTo(x, y)
                    fillPath.lineTo(x, y)
                }
            }
            fillPath.lineTo(spRight, rect.bottom)
            fillPath.close()

            val sparkColor = if (item.ret >= 0) Color.parseColor("#FB7185") else Color.parseColor("#38BDF8")
            val sparkFillTop = if (item.ret >= 0) Color.parseColor("#33FB7185") else Color.parseColor("#3338BDF8")

            p.shader = LinearGradient(0f, spTop, 0f, rect.bottom, sparkFillTop, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawPath(fillPath, p)
            p.shader = null

            p.style = Paint.Style.STROKE
            p.strokeWidth = 3.5f
            p.strokeCap = Paint.Cap.ROUND
            p.strokeJoin = Paint.Join.ROUND
            p.color = sparkColor
            c.drawPath(linePath, p)
            p.style = Paint.Style.FILL
        }
        c.restore()

        // Card crisp border
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f
        p.color = Color.parseColor("#243652")
        c.drawRoundRect(rect, 32f, 32f, p)
        p.style = Paint.Style.FILL

        // Header Row: Market Name (left) + Daily % Pill (right)
        p.color = Color.parseColor("#F8FAFC")
        p.textSize = 34f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText(item.name, rect.left + 26f, rect.top + 52f, p)

        val retStr = String.format("%s%.2f%%", if (item.ret > 0) "+" else "", item.ret)
        val retColor = if (item.ret >= 0) Color.parseColor("#FDA4AF") else Color.parseColor("#7DD3FC")
        val retBg = if (item.ret >= 0) Color.parseColor("#29FB7185") else Color.parseColor("#2938BDF8")
        p.textSize = 23f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        val retTw = p.measureText(retStr)
        val retRect = RectF(rect.right - 26f - retTw - 24f, rect.top + 22f, rect.right - 26f, rect.top + 58f)
        p.color = retBg
        c.drawRoundRect(retRect, 18f, 18f, p)
        p.color = retColor
        p.textAlign = Paint.Align.CENTER
        c.drawText(retStr, retRect.centerX(), retRect.centerY() + 8f, p)

        // Hero Vector Direction Icon (Center)
        val iconCy = rect.top + 138f
        p.shader = RadialGradient(cx, iconCy, 66f, Color.parseColor(glowHex), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawCircle(cx, iconCy, 66f, p)
        p.shader = null

        val arrowPath = Path()
        when (item.code) {
            "HIGH_UP" -> {
                arrowPath.moveTo(cx, iconCy - 40f)
                arrowPath.lineTo(cx + 46f, iconCy + 28f)
                arrowPath.lineTo(cx, iconCy + 12f)
                arrowPath.lineTo(cx - 46f, iconCy + 28f)
                arrowPath.close()
                p.color = accent
                c.drawPath(arrowPath, p)
            }
            "HIGH_DOWN" -> {
                arrowPath.moveTo(cx, iconCy + 40f)
                arrowPath.lineTo(cx + 46f, iconCy - 28f)
                arrowPath.lineTo(cx, iconCy - 12f)
                arrowPath.lineTo(cx - 46f, iconCy - 28f)
                arrowPath.close()
                p.color = accent
                c.drawPath(arrowPath, p)
            }
            else -> {
                // Sleek balanced neutral bar + glowing center diamond
                p.color = Color.parseColor("#64748B")
                c.drawRoundRect(RectF(cx - 52f, iconCy - 6f, cx + 52f, iconCy + 6f), 6f, 6f, p)
                val diamond = Path().apply {
                    moveTo(cx, iconCy - 18f)
                    lineTo(cx + 18f, iconCy)
                    lineTo(cx, iconCy + 18f)
                    lineTo(cx - 18f, iconCy)
                    close()
                }
                p.color = Color.parseColor("#2DD4BF")
                c.drawPath(diamond, p)
            }
        }

        // Exact Web App Signal Pill
        p.textSize = 25f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        val lblW = p.measureText(item.label)
        val pillRect = RectF(cx - lblW / 2f - 24f, iconCy + 54f, cx + lblW / 2f + 24f, iconCy + 98f)
        p.color = pillBg
        c.drawRoundRect(pillRect, 22f, 22f, p)
        p.color = labelColor
        c.drawText(item.label, cx, pillRect.centerY() + 9f, p)

        // Index Price at bottom-left above sparkline
        p.textAlign = Paint.Align.LEFT
        p.color = Color.parseColor("#94A3B8")
        p.textSize = 22f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        c.drawText(item.price, rect.left + 26f, rect.bottom - 24f, p)
    }
}
