package com.daybook.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.widget.RemoteViews
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class DaybookWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_REFRESH = "com.daybook.widget.ACTION_REFRESH"
        const val PREFS_NAME = "daybook_widget_prefs"
        const val KEY_WORKER_URL = "worker_url"
        const val WEB_APP_URL = "https://yanggun1219.github.io/Index-daybook/"
        const val DEFAULT_WORKER_URL = "https://index-daybook-live.yanggun1219.workers.dev"

        fun normalizeWorkerUrl(raw: String): String {
            var u = raw.trim()
            val idx = u.indexOf("worker=")
            if (idx >= 0) {
                u = u.substring(idx + 7).substringBefore("&")
                try { u = Uri.decode(u) } catch (_: Exception) {}
            }
            u = u.trim().trimEnd('/')
            if (u.endsWith("/widget")) u = u.removeSuffix("/widget")
            if (u.endsWith("/live")) u = u.removeSuffix("/live")
            return u.trimEnd('/')
        }

        fun triggerUpdate(context: Context) {
            val intent = Intent(context, DaybookWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllAsync(context, appWidgetManager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, DaybookWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                updateAllAsync(context, mgr, ids)
            }
        }
    }

    private fun updateAllAsync(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pendingResult = goAsync()
        Thread {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val rawSaved = prefs.getString(KEY_WORKER_URL, "") ?: ""
                val baseUrl = normalizeWorkerUrl(if (rawSaved.isBlank()) DEFAULT_WORKER_URL else rawSaved)
                val views = RemoteViews(context.packageName, R.layout.widget_daybook)

                val refreshIntent = Intent(context, DaybookWidgetProvider::class.java).apply {
                    action = ACTION_REFRESH
                }
                val refreshPi = PendingIntent.getBroadcast(
                    context, 1001, refreshIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_refresh, refreshPi)

                val openWebIntent = Intent(Intent.ACTION_VIEW, Uri.parse(WEB_APP_URL))
                val openWebPi = PendingIntent.getActivity(
                    context, 1002, openWebIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, openWebPi)

                views.setTextViewText(R.id.widget_updated, "갱신 중...")
                for (id in ids) mgr.updateAppWidget(id, views)

                val conn = (URL("$baseUrl/widget").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 12000
                    setRequestProperty("User-Agent", "IndexDaybookWidget/1.3")
                }

                val code = conn.responseCode
                if (code == 200) {
                    val text = conn.inputStream.bufferedReader().use { it.readText() }
                    val json = JSONObject(text)
                    val updated = json.optString("updatedKst", "완료")
                    views.setTextViewText(R.id.widget_updated, updated)

                    val items = json.optJSONArray("items")
                    val nameIds = intArrayOf(R.id.t0_name, R.id.t1_name)
                    val arrowIds = intArrayOf(R.id.t0_arrow, R.id.t1_arrow)
                    val badgeIds = intArrayOf(R.id.t0_badge, R.id.t1_badge)
                    val subIds = intArrayOf(R.id.t0_sub, R.id.t1_sub)

                    val upColor = Color.parseColor("#FB7185")
                    val downColor = Color.parseColor("#60A5FA")
                    val flatColor = Color.parseColor("#94A3B8")

                    if (items != null) {
                        for (i in 0 until minOf(2, items.length())) {
                            val it = items.getJSONObject(i)
                            val name = it.optString("name", "-")
                            val p = it.optDouble("p", 50.0)
                            val dir = it.optString("dir", if (p >= 58.0) "up" else if (p <= 42.0) "down" else "flat")
                            val badge = it.optString("badge", if (dir == "up") "상승 우위" else if (dir == "down") "하락 경계" else "관망")
                            val ret = it.optDouble("ret", 0.0)
                            val price = it.optString("price", "")

                            val (arrow, color) = when (dir) {
                                "up" -> Pair("▲", upColor)
                                "down" -> Pair("▼", downColor)
                                else -> Pair("▬", flatColor)
                            }

                            views.setTextViewText(nameIds[i], name)
                            views.setTextViewText(arrowIds[i], arrow)
                            views.setTextColor(arrowIds[i], color)
                            views.setTextViewText(badgeIds[i], badge)
                            views.setTextColor(badgeIds[i], color)

                            val retStr = String.format("%s%.2f%%", if (ret > 0) "+" else "", ret)
                            views.setTextViewText(subIds[i], if (price.isNotEmpty() && price != "-") "$price ($retStr)" else retStr)
                        }
                    }
                } else {
                    views.setTextViewText(R.id.widget_updated, "오류 HTTP $code")
                }
                for (id in ids) mgr.updateAppWidget(id, views)
            } catch (e: Exception) {
                val views = RemoteViews(context.packageName, R.layout.widget_daybook)
                views.setTextViewText(R.id.widget_updated, "연결 지연")
                for (id in ids) mgr.updateAppWidget(id, views)
            } finally {
                pendingResult.finish()
            }
        }.start()
    }
}
