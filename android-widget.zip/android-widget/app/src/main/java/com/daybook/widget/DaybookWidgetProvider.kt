package com.daybook.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.widget.RemoteViews
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class DaybookWidgetProvider : AppWidgetProvider() {

    data class CardItem(
        val name: String,
        val code: String,
        val label: String,
        val price: String,
        val ret: Double,
        val spark: List<Double>,
        val phaseTag: String = "다음 시초가",
        val openSub: String = "",
        val dirScore: Int = 0,
        val delta: Int = 0
    )

    companion object {
        const val ACTION_REFRESH = "com.daybook.widget.ACTION_REFRESH"
        const val PREFS_NAME = "daybook_widget_prefs"
        const val KEY_WORKER_URL = "worker_url"
        const val KEY_DARK_MODE = "dark_mode"
        const val WEB_APP_URL = "https://yanggun1219.github.io/Index-daybook/"
        const val DATA_JS_URL = "https://yanggun1219.github.io/Index-daybook/data.js"
        const val DEFAULT_WORKER_URL = "https://index-daybook-live.yanggun1219.workers.dev"

        fun normalizeWorkerUrl(raw: String): String {
            var u = raw.trim()
            val idx = u.indexOf("worker=")
            if (idx >= 0) {
                u = u.substring(idx + 7).substringBefore("&")
                try { u = Uri.decode(u) } catch (_: Exception) {}
            }
            u = u.trim().trimEnd('/')
            if (u.endsWith("/widget")) u = u.removeSuffix("/widget")
            if (u.endsWith("/live")) u = u.removeSuffix("/live")
            return u.trimEnd('/')
        }

        fun triggerUpdate(context: Context) {
            val intent = Intent(context, DaybookWidgetProvider::class.java).apply {
                action = ACTION_REFRESH
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAllAsync(context, appWidgetManager, appWidgetIds)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, DaybookWidgetProvider::class.java))
            if (ids.isNotEmpty()) {
                updateAllAsync(context, mgr, ids)
            }
        }
    }

    private fun httpGetText(urlStr: String, timeoutMs: Int = 6000): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            setRequestProperty("User-Agent", "IndexDaybookWidget/2.4")
        }
        try {
            if (conn.responseCode != 200) throw Exception("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun fetchAndCompute(context: Context, baseUrl: String): ExactModelEngine.WidgetResult {
        val cacheFile = File(context.cacheDir, "data_cached.js")
        var dataJs: String? = null
        var dataErr: Throwable? = null
        var liveJsonStr = "{}"

        // Parallel fetch: data.js + /live (keeps total network time ~0.5-1.5s)
        val t1 = Thread {
            try {
                val fetched = httpGetText("$DATA_JS_URL?t=${System.currentTimeMillis() / 60000}", 6000)
                cacheFile.writeText(fetched, Charsets.UTF_8)
                dataJs = fetched
            } catch (e: Throwable) {
                if (cacheFile.exists()) {
                    dataJs = cacheFile.readText(Charsets.UTF_8)
                } else {
                    dataErr = e
                }
            }
        }
        val t2 = Thread {
            try {
                liveJsonStr = httpGetText("$baseUrl/live", 6000)
            } catch (_: Throwable) {
                liveJsonStr = "{}"
            }
        }
        t1.start()
        t2.start()
        t1.join(6500)
        t2.join(6500)

        val finalData = dataJs ?: throw (dataErr ?: Exception("data.js 수신 지연"))
        return ExactModelEngine.compute(finalData, liveJsonStr)
    }

    private fun updateAllAsync(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        val pendingResult = goAsync()
        Thread {
            try {
                val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                val rawSaved = prefs.getString(KEY_WORKER_URL, "") ?: ""
                val baseUrl = normalizeWorkerUrl(if (rawSaved.isBlank()) DEFAULT_WORKER_URL else rawSaved)

                val isDark = prefs.getBoolean(KEY_DARK_MODE, false)
                val rawRes = fetchAndCompute(context, baseUrl)
                val editor = prefs.edit()
                val itemsWithDelta = rawRes.items.map { it ->
                    val pKey = "prev_dir_score_${it.name}"
                    val hasPrev = prefs.contains(pKey)
                    val prevScore = prefs.getInt(pKey, it.dirScore)
                    val delta = if (hasPrev) it.dirScore - prevScore else 0
                    editor.putInt(pKey, it.dirScore)
                    it.copy(delta = delta)
                }
                editor.apply()
                val views = buildBaseViews(context)
                views.setImageViewBitmap(R.id.widget_canvas, renderWidgetBitmap(rawRes.updatedKst, itemsWithDelta, isDark))
                for (id in ids) mgr.updateAppWidget(id, views)
            } catch (e: Throwable) {
                val views = buildBaseViews(context)
                val msg = (e.message ?: e.javaClass.simpleName).take(26)
                views.setImageViewBitmap(
                    R.id.widget_canvas,
                    renderWidgetBitmap(
                        updated = "오류: $msg",
                        items = listOf(
                            CardItem("코스피", "NEUTRAL", "재시도 필요", "-", 0.0, emptyList()),
                            CardItem("나스닥", "NEUTRAL", "재시도 필요", "-", 0.0, emptyList())
                        )
                    )
                )
                for (id in ids) mgr.updateAppWidget(id, views)
            } finally {
                pendingResult.finish()
            }
        }.start()
    }

    private fun buildBaseViews(context: Context): RemoteViews {
        val views = RemoteViews(context.packageName, R.layout.widget_daybook)
        val refreshIntent = Intent(context, DaybookWidgetProvider::class.java).apply {
            action = ACTION_REFRESH
        }
        val refreshPi = PendingIntent.getBroadcast(
            context, 1001, refreshIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshPi)

        val openWebIntent = Intent(Intent.ACTION_VIEW, Uri.parse(WEB_APP_URL))
        val openWebPi = PendingIntent.getActivity(
            context, 1002, openWebIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_root, openWebPi)
        return views
    }

    private fun renderWidgetBitmap(updated: String, items: List<CardItem>, isDark: Boolean = false): Bitmap {
        val w = 960
        val h = 460
        val scale = 0.72f
        val bmp = Bitmap.createBitmap((w * scale).toInt(), (h * scale).toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(scale, scale)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)

        // Outer Soft Flat Container
        val outerBg = if (isDark) Color.parseColor("#161A22") else Color.parseColor("#FFFFFF")
        val outerBorder = if (isDark) Color.parseColor("#252B38") else Color.parseColor("#E5E7EB")
        val titleCol = if (isDark) Color.parseColor("#F8FAFC") else Color.parseColor("#111827")
        val mutedCol = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")
        val btnBg = if (isDark) Color.parseColor("#232836") else Color.parseColor("#F3F4F6")

        val outerRect = RectF(4f, 4f, w - 4f, h - 4f)
        p.color = outerBg
        c.drawRoundRect(outerRect, 44f, 44f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f
        p.color = outerBorder
        c.drawRoundRect(outerRect, 44f, 44f, p)
        p.style = Paint.Style.FILL

        // Header: Status Dot + Title + Stamp + Refresh Circle
        val dotCol = if (items.firstOrNull()?.code == "HIGH_UP") {
            if (isDark) Color.parseColor("#FF5A6E") else Color.parseColor("#E11D48")
        } else if (items.firstOrNull()?.code == "HIGH_DOWN") {
            if (isDark) Color.parseColor("#4DA3FF") else Color.parseColor("#2563EB")
        } else {
            Color.parseColor("#64748B")
        }
        p.color = dotCol
        c.drawCircle(46f, 48f, 9f, p)

        p.color = titleCol
        p.textSize = 28f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText("지수 관측소", 68f, 58f, p)

        p.color = mutedCol
        p.textSize = 21f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        c.drawText(updated, 232f, 56f, p)

        // Flat Refresh Pill
        val btnCx = w - 54f
        val btnCy = 48f
        p.color = btnBg
        c.drawCircle(btnCx, btnCy, 26f, p)
        p.color = titleCol
        p.textSize = 28f
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText("↻", btnCx, btnCy + 10f, p)
        p.textAlign = Paint.Align.LEFT

        // Two Soft Pastel Flat Cards
        val padX = 24f
        val gap = 20f
        val cardTop = 92f
        val cardBottom = h - 22f
        val cardW = (w - padX * 2 - gap) / 2f

        for (idx in 0 until minOf(2, items.size)) {
            val left = padX + idx * (cardW + gap)
            drawPastelCard(c, RectF(left, cardTop, left + cardW, cardBottom), items[idx], isDark)
        }
        return bmp
    }

    private fun blackTypeface(): Typeface {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            Typeface.create(Typeface.SANS_SERIF, 900, false)
        } else {
            Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
    }

    private fun drawPastelCard(c: Canvas, rect: RectF, item: CardItem, isDark: Boolean) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)

        val upCol = if (isDark) Color.parseColor("#FF5A6E") else Color.parseColor("#E11D48")
        val downCol = if (isDark) Color.parseColor("#4DA3FF") else Color.parseColor("#2563EB")
        val flatCol = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")

        val cardBg = when (item.code) {
            "HIGH_UP" -> if (isDark) Color.parseColor("#281820") else Color.parseColor("#FFF1F2")
            "HIGH_DOWN" -> if (isDark) Color.parseColor("#152033") else Color.parseColor("#EFF6FF")
            else -> if (isDark) Color.parseColor("#1C222D") else Color.parseColor("#F1F5F9")
        }
        val sigCol = when (item.code) {
            "HIGH_UP" -> upCol
            "HIGH_DOWN" -> downCol
            else -> flatCol
        }
        val textPrimary = if (isDark) Color.parseColor("#F8FAFC") else Color.parseColor("#111827")
        val textMuted = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")
        val dividerCol = if (isDark) Color.parseColor("#1AFFFFFF") else Color.parseColor("#140F172A")
        val whiteBox = if (isDark) Color.parseColor("#17FFFFFF") else Color.parseColor("#FFFFFF")

        // Soft Pastel Card Fill (Pure Flat — matches Web App v8.1)
        p.color = cardBg
        c.drawRoundRect(rect, 34f, 34f, p)

        // Row 1: Market Name (left) + Daily % Pill (right)
        p.color = textPrimary
        p.textSize = 27f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText(item.name, rect.left + 26f, rect.top + 48f, p)

        val retStr = String.format("%s%.2f%%", if (item.ret > 0) "+" else "", item.ret)
        val retCol = if (item.ret >= 0) upCol else downCol
        val retPillBg = if (item.ret >= 0) {
            if (isDark) Color.parseColor("#2BFF5A6E") else Color.parseColor("#1FE11D48")
        } else {
            if (isDark) Color.parseColor("#2B4DA3FF") else Color.parseColor("#1F2563EB")
        }
        p.textSize = 21f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        val retW = p.measureText(retStr)
        val retRect = RectF(rect.right - 24f - retW - 22f, rect.top + 22f, rect.right - 24f, rect.top + 56f)
        p.color = retPillBg
        c.drawRoundRect(retRect, 14f, 14f, p)
        p.color = retCol
        p.textAlign = Paint.Align.CENTER
        c.drawText(retStr, retRect.centerX(), retRect.centerY() + 8f, p)
        p.textAlign = Paint.Align.LEFT

        // Row 2: BIG Extra-Black Current Index (matches Web App font-black)
        p.color = textPrimary
        p.textSize = 55f
        p.typeface = blackTypeface()
        p.isFakeBoldText = true
        p.letterSpacing = -0.03f
        c.drawText(item.price, rect.left + 26f, rect.top + 124f, p)
        p.isFakeBoldText = false
        p.letterSpacing = 0f

        // Row 3: Small Open Price Reference
        if (item.openSub.isNotEmpty()) {
            p.color = textMuted
            p.textSize = 19f
            p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            c.drawText(item.openSub, rect.left + 26f, rect.top + 156f, p)
        }

        // Hairline Divider
        p.color = dividerCol
        c.drawRect(rect.left + 24f, rect.top + 184f, rect.right - 24f, rect.top + 186f, p)

        // Bottom Row (Matches Web App v8.1: [Icon Box] [Phase + Bold Forecast]   [Score Box])
        val rowCy = rect.top + 264f

        // 1) Left White Rounded Icon Box (64x64)
        val iconRect = RectF(rect.left + 24f, rowCy - 34f, rect.left + 88f, rowCy + 30f)
        p.color = whiteBox
        c.drawRoundRect(iconRect, 20f, 20f, p)

        // Draw crisp vector trend icon inside iconRect (same as Web App SVG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = sigCol
        val icx = iconRect.centerX()
        val icy = iconRect.centerY()
        when (item.code) {
            "HIGH_UP" -> {
                val path = Path().apply {
                    moveTo(icx - 16f, icy + 10f)
                    lineTo(icx - 4f, icy - 2f)
                    lineTo(icx + 4f, icy + 6f)
                    lineTo(icx + 16f, icy - 10f)
                }
                c.drawPath(path, p)
                val head = Path().apply {
                    moveTo(icx + 6f, icy - 10f)
                    lineTo(icx + 16f, icy - 10f)
                    lineTo(icx + 16f, icy)
                }
                c.drawPath(head, p)
            }
            "HIGH_DOWN" -> {
                val path = Path().apply {
                    moveTo(icx - 16f, icy - 10f)
                    lineTo(icx - 4f, icy + 2f)
                    lineTo(icx + 4f, icy - 6f)
                    lineTo(icx + 16f, icy + 10f)
                }
                c.drawPath(path, p)
                val head = Path().apply {
                    moveTo(icx + 6f, icy + 10f)
                    lineTo(icx + 16f, icy + 10f)
                    lineTo(icx + 16f, icy)
                }
                c.drawPath(head, p)
            }
            else -> {
                c.drawLine(icx - 15f, icy, icx + 15f, icy, p)
                p.style = Paint.Style.FILL
                c.drawCircle(icx, icy, 6f, p)
            }
        }
        p.style = Paint.Style.FILL

        // 2) Middle Phase Sub-label + Bold Direction Text
        val textX = iconRect.right + 16f
        p.color = textMuted
        p.textSize = 18f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        c.drawText(item.phaseTag, textX, rowCy - 10f, p)

        p.color = sigCol
        p.textSize = 29f
        p.typeface = blackTypeface()
        p.isFakeBoldText = true
        c.drawText(item.label, textX, rowCy + 24f, p)
        p.isFakeBoldText = false

        // 3) Right White Rounded Score Box (-100 ~ +100 + Delta)
        val scoreBox = RectF(rect.right - 122f, rowCy - 40f, rect.right - 22f, rowCy + 36f)
        p.color = whiteBox
        c.drawRoundRect(scoreBox, 22f, 22f, p)

        val scoreStr = (if (item.dirScore > 0) "+" else "") + item.dirScore.toString()
        p.color = if (item.dirScore > 0) upCol else if (item.dirScore < 0) downCol else flatCol
        p.textSize = 34f
        p.textAlign = Paint.Align.CENTER
        p.typeface = blackTypeface()
        p.isFakeBoldText = true
        c.drawText(scoreStr, scoreBox.centerX(), scoreBox.centerY() + 3f, p)
        p.isFakeBoldText = false

        if (item.delta != 0) {
            val dStr = if (item.delta > 0) "▲+${item.delta}" else "▼${item.delta}"
            p.color = if (item.delta > 0) upCol else downCol
            p.textSize = 16f
            c.drawText(dStr, scoreBox.centerX(), scoreBox.bottom - 10f, p)
        } else {
            p.color = textMuted
            p.textSize = 14f
            c.drawText("방향 점수", scoreBox.centerX(), scoreBox.bottom - 10f, p)
        }
        p.textAlign = Paint.Align.LEFT
    }
}
