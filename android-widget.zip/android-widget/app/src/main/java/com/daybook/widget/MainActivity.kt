package com.daybook.widget

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(DaybookWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val savedRaw = prefs.getString(DaybookWidgetProvider.KEY_WORKER_URL, "") ?: ""
        val savedUrl = if (savedRaw.isBlank()) DaybookWidgetProvider.DEFAULT_WORKER_URL else savedRaw

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#070D19"))
            setPadding(56, 96, 56, 56)
        }

        val title = TextView(this).apply {
            text = "지수 관측소 네이티브 위젯 v2.3"
            setTextColor(Color.parseColor("#2DD4BF"))
            textSize = 22f
            setPadding(0, 0, 0, 16)
        }

        val desc = TextView(this).apply {
            text = "웹 앱과 완전히 동일한 data.js + model.js 엔진을 폰에서 직접 실행해 코스피·나스닥 방향 화살표와 신호 문구를 100% 똑같이 표시합니다."
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 14f
            setPadding(0, 0, 0, 36)
        }

        val urlInput = EditText(this).apply {
            hint = "https://index-daybook-live.yanggun1219.workers.dev"
            setText(savedUrl)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#64748B"))
            setBackgroundColor(Color.parseColor("#0F172A"))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setPadding(32, 28, 32, 28)
        }

        val saveBtn = Button(this).apply {
            text = "주소 저장 및 위젯 즉시 새로고침"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0D9488"))
            setPadding(24, 28, 24, 28)
            setOnClickListener {
                val url = DaybookWidgetProvider.normalizeWorkerUrl(urlInput.text.toString())
                urlInput.setText(url)
                if (url.isNotEmpty() && !url.startsWith("https://")) {
                    Toast.makeText(this@MainActivity, "https:// 로 시작하는 Workers 주소를 입력해 주세요.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                prefs.edit().putString(DaybookWidgetProvider.KEY_WORKER_URL, url).apply()
                DaybookWidgetProvider.triggerUpdate(this@MainActivity)
                Toast.makeText(this@MainActivity, "저장 완료! 위젯을 최신 데이터로 갱신 중입니다.", Toast.LENGTH_LONG).show()
            }
        }

        val openBtn = Button(this).apply {
            text = "전체 웹 앱 열기"
            setTextColor(Color.parseColor("#E2E8F0"))
            setBackgroundColor(Color.parseColor("#1E293B"))
            setPadding(24, 24, 24, 24)
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DaybookWidgetProvider.WEB_APP_URL)))
            }
        }

        val guide = TextView(this).apply {
            text = "\n홈 화면 추가 방법:\n1. 갤럭시 바탕화면 빈 곳을 길게 누름\n2. 하단 [위젯] → [지수 관측소 위젯] 선택\n3. 홈 화면에 배치 (4×2 크기 권장)"
            setTextColor(Color.parseColor("#64748B"))
            textSize = 13f
            gravity = Gravity.START
            setPadding(0, 36, 0, 0)
        }

        val lpSpace = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 24 }

        root.addView(title)
        root.addView(desc)
        root.addView(urlInput)
        root.addView(saveBtn, lpSpace)
        root.addView(openBtn, lpSpace)
        root.addView(guide)
        setContentView(root)
    }
}
