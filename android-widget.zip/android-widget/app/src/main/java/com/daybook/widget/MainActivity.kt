package com.daybook.widget

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(DaybookWidgetProvider.PREFS_NAME, Context.MODE_PRIVATE)
        val savedRaw = prefs.getString(DaybookWidgetProvider.KEY_WORKER_URL, "") ?: ""
        val savedUrl = if (savedRaw.isBlank()) DaybookWidgetProvider.DEFAULT_WORKER_URL else savedRaw
        var isDark = prefs.getBoolean(DaybookWidgetProvider.KEY_DARK_MODE, false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#11141B"))
            setPadding(56, 96, 56, 56)
        }

        val title = TextView(this).apply {
            text = "지수 관측소 위젯 v3.5 (소프트 파스텔)"
            setTextColor(Color.parseColor("#FF5A6E"))
            textSize = 21f
            setPadding(0, 0, 0, 16)
        }

        val desc = TextView(this).apply {
            text = "장전에는 다음 시초가, 장중에는 시초가 대비 오늘 종가 방향을 소프트 파스텔 디자인으로 표시합니다."
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 14f
            setPadding(0, 0, 0, 32)
        }

        val urlInput = EditText(this).apply {
            hint = "https://index-daybook-live.yanggun1219.workers.dev"
            setText(savedUrl)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#64748B"))
            setBackgroundColor(Color.parseColor("#1D222D"))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setPadding(32, 28, 32, 28)
        }

        val themeBtn = Button(this).apply {
            text = if (isDark) "위젯 테마: 다크 모드 (눌러서 라이트로)" else "위젯 테마: 라이트 모드 (눌러서 다크로)"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#252C3A"))
            setPadding(24, 24, 24, 24)
            setOnClickListener {
                isDark = !isDark
                prefs.edit().putBoolean(DaybookWidgetProvider.KEY_DARK_MODE, isDark).apply()
                text = if (isDark) "위젯 테마: 다크 모드 (눌러서 라이트로)" else "위젯 테마: 라이트 모드 (눌러서 다크로)"
                DaybookWidgetProvider.triggerUpdate(this@MainActivity)
                Toast.makeText(this@MainActivity, if (isDark) "다크 위젯으로 변경했습니다." else "라이트 위젯으로 변경했습니다.", Toast.LENGTH_SHORT).show()
            }
        }

        val saveBtn = Button(this).apply {
            text = "주소 저장 및 위젯 즉시 새로고침"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#E11D48"))
            setPadding(24, 28, 24, 28)
            setOnClickListener {
                val url = DaybookWidgetProvider.normalizeWorkerUrl(urlInput.text.toString())
                urlInput.setText(url)
                if (url.isNotEmpty() && !url.startsWith("https://")) {
                    Toast.makeText(this@MainActivity, "https:// 로 시작하는 Workers 주소를 입력해 주세요.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                prefs.edit().putString(DaybookWidgetProvider.KEY_WORKER_URL, url).apply()
                DaybookWidgetProvider.triggerUpdate(this@MainActivity)
                Toast.makeText(this@MainActivity, "저장 완료! 위젯을 최신 데이터로 갱신 중입니다.", Toast.LENGTH_LONG).show()
            }
        }

        val openBtn = Button(this).apply {
            text = "전체 웹 앱 열기"
            setTextColor(Color.parseColor("#E2E8F0"))
            setBackgroundColor(Color.parseColor("#1D222D"))
            setPadding(24, 24, 24, 24)
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DaybookWidgetProvider.WEB_APP_URL)))
            }
        }

        val guide = TextView(this).apply {
            text = "\n홈 화면 추가 방법:\n1. 갤럭시 바탕화면 빈 곳을 길게 누름\n2. 하단 [위젯] → [지수 관측소 위젯] 선택\n3. 홈 화면에 배치 (4×2 크기 권장)"
            setTextColor(Color.parseColor("#64748B"))
            textSize = 13f
            gravity = Gravity.START
            setPadding(0, 32, 0, 0)
        }

        val lpSpace = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 22 }

        root.addView(title)
        root.addView(desc)
        root.addView(urlInput)
        root.addView(themeBtn, lpSpace)
        root.addView(saveBtn, lpSpace)
        root.addView(openBtn, lpSpace)
        root.addView(guide)
        setContentView(root)
    }
}
